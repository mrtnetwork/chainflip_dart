import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:chain_flip/src/exception/exception.dart';
import 'package:chain_flip/src/sdk/api/cf/utils/utils.dart';
import 'package:on_chain/on_chain.dart';
import 'package:on_chain/solidity/address/core.dart';
import 'package:polkadot_dart/polkadot_dart.dart';

class StramBlockResponse {
  final String extrinsic;
  final String block;
  final int blockNumber;
  final List<SubstrateEvent> events;
  const StramBlockResponse(
      {required this.events,
      required this.block,
      required this.extrinsic,
      required this.blockNumber});
}

class EVMTransactionParams {
  final int? gasLimit;
  final BigInt? gasPrice;
  final BigInt? maxFeePerGas;
  final BigInt? maxPriorityFeePerGas;
  final int? accountNonce;
  final List<AccessListEntry>? accessListEntry;
  final ETHTransactionType transactionType;
  final EIP1559FeeRate? feeRate;
  EVMTransactionParams._(
      {this.gasLimit,
      this.gasPrice,
      this.maxFeePerGas,
      this.maxPriorityFeePerGas,
      this.accountNonce,
      required this.transactionType,
      List<AccessListEntry>? accessListEntry,
      this.feeRate})
      : accessListEntry = accessListEntry?.immutable;
  factory EVMTransactionParams.legacy(
      {BigInt? gasPrice, int? gasLimit, int? accountNonce}) {
    return EVMTransactionParams._(
        transactionType: ETHTransactionType.legacy,
        gasPrice: gasPrice,
        gasLimit: gasLimit,
        accountNonce: accountNonce);
  }
  factory EVMTransactionParams.eip2930(
      {BigInt? gasPrice,
      int? gasLimit,
      int? accountNonce,
      List<AccessListEntry>? accessListEntry}) {
    return EVMTransactionParams._(
        transactionType: ETHTransactionType.eip2930,
        gasPrice: gasPrice,
        gasLimit: gasLimit,
        accessListEntry: accessListEntry,
        accountNonce: accountNonce);
  }
  factory EVMTransactionParams.eip1559(
      {BigInt? maxFeePerGas,
      BigInt? maxPriorityFeePerGas,
      int? gasLimit,
      int? accountNonce,
      List<AccessListEntry>? accessListEntry,
      EIP1559FeeRate? feeRate}) {
    if (maxFeePerGas == null && maxPriorityFeePerGas != null ||
        maxFeePerGas != null ||
        maxPriorityFeePerGas == null) {
      throw DartChainFlipException(
          "For EIP-1559, both maxFeePerGas and maxPriorityFeePerGas are required fields. Alternatively, you may leave both fields unspecified.");
    } else if (maxFeePerGas != null && feeRate != null) {
      throw DartChainFlipException(
          "For automatically filled transaction fees, the maxFeePerGas and maxPriorityFeePerGas fields must be left unspecified.");
    }
    return EVMTransactionParams._(
        transactionType: ETHTransactionType.eip1559,
        gasLimit: gasLimit,
        maxFeePerGas: maxFeePerGas,
        maxPriorityFeePerGas: maxPriorityFeePerGas,
        accessListEntry: accessListEntry,
        accountNonce: accountNonce,
        feeRate: feeRate);
  }

  void filledTransaction(ETHTransactionBuilder transaction) {
    if (accountNonce != null) {
      transaction.setNonce(accountNonce!);
    }
    if (gasLimit != null) {
      transaction.setGasLimit(BigInt.from(gasLimit!));
    }
    if (gasPrice != null) {
      transaction.setGasPrice(gasPrice!);
    }
    if (maxFeePerGas != null) {
      transaction.setEIP1559FeeDetails(maxFeePerGas!, maxPriorityFeePerGas!);
    }
    if (accessListEntry != null) {
      transaction.setAccessList(accessListEntry);
    }
  }
}

class TokenContractAddress {
  final List<int> bytes;
  final String address;
  TokenContractAddress._({required this.address, required List<int> bytes})
      : bytes = bytes.asImmutableBytes;
  factory TokenContractAddress.ethereum(ETHAddress address) {
    return TokenContractAddress._(
        address: address.address,
        bytes: CfApiUtils.asEthereumUnit32(address.toBytes()));
  }
  factory TokenContractAddress.solana(SolAddress address) {
    return TokenContractAddress._(
        address: address.address,
        bytes: CfApiUtils.asEthereumUnit32(address.toBytes()));
  }
}

class GetPendingRedemptionResult {
  final BigInt amount;
  final SolidityAddress redeemAddress;
  final int startTime;
  final int expiryTime;
  final SolidityAddress executor;

  const GetPendingRedemptionResult(
      {required this.amount,
      required this.redeemAddress,
      required this.startTime,
      required this.executor,
      required this.expiryTime});
}

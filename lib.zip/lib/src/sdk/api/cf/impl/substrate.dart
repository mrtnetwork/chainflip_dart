import 'dart:async';
import 'package:blockchain_utils/utils/utils.dart';
import 'package:chain_flip/src/exception/exception.dart';
import 'package:chain_flip/src/provider/models/rpc/response_types.dart';
import 'package:chain_flip/src/sdk/api/cf/utils/utils.dart';
import 'package:chain_flip/src/sdk/chain/types/chain_flip_networks.dart';
import 'package:chain_flip/src/sdk/api/cf/core/core.dart';
import 'package:chain_flip/src/sdk/api/cf/models/models.dart';
import 'package:chain_flip/src/sdk/api/cf/operations/substrate.dart';
import 'package:polkadot_dart/polkadot_dart.dart';

class _ChainFlipApiConst {
  static const String depositAddressReadyMethodName = "SwapDepositAddressReady";
  static const String liquidityDepositAddressReadyMethodName =
      "LiquidityDepositAddressReady";
}

mixin SubstrateApiImpl on CfSubstrateApiCore {
  MetadataApi get api;
  CfNetwork get network;
  Future<int> getAccountNonce(
      {required SubstrateRPC provider,
      required SubstrateAddress source}) async {
    final data = await api.getStorage(
        request: QueryStorageRequest<Map<String, dynamic>>(
            palletNameOrIndex: "System",
            methodName: "account",
            input: source.toBytes(),
            identifier: 0),
        rpc: provider,
        fromTemplate: false);
    return data.result["nonce"];
  }

  Extrinsic signPayload(
      {required LegacyTransactionPayload payload,
      required SubstratePrivateKey signer}) {
    final multiSignature = signer.multiSignature(payload.serialzeSign());
    final signature = LegacyExtrinsicSignature(
        signature: multiSignature,
        address: signer.toAddress().toMultiAddress(),
        era: payload.era,
        tip: payload.tip,
        nonce: payload.nonce);
    return Extrinsic(signature: signature, methodBytes: payload.method);
  }

  Future<LegacyTransactionPayload> buildOperationPayload(
      {required SubstrateRPC provider,
      required ChainFlipSubstrateOperation operation,
      required SubstrateAddress source,
      String? genesisHash,
      String? blockHash,
      int? nonce}) async {
    final version = api.runtimeVersion();
    genesisHash ??= await provider
        .request(const SubstrateRPCChainGetBlockHash<String>(number: 0));
    nonce ??= await getAccountNonce(provider: provider, source: source);
    blockHash ??=
        await provider.request(const SubstrateRPCChainChainGetFinalizedHead());
    final blockHeader = await provider
        .request(SubstrateRPCChainChainGetHeader(atBlockHash: blockHash));

    final methodBytes = operation.serializeCall(api.metadata);
    final era = blockHeader.toMortalEra();
    return LegacyTransactionPayload(
        blockHash: SubstrateBlockHash.hash(blockHash!),
        era: era,
        genesisHash: SubstrateBlockHash.hash(genesisHash!),
        method: methodBytes,
        nonce: nonce,
        specVersion: version.specVersion,
        transactionVersion: version.transactionVersion,
        tip: BigInt.zero);
  }

  Future<String> submitExtrinsic(
      {required SubstrateRPC provider, required Extrinsic extrinsic}) async {
    return await provider.request(
        SubstrateRPCAuthorSubmitExtrinsic(extrinsic.toHex(prefix: "0x")));
  }

  Future<BrokerRequestSwapDepositAddressResponse> requestSwapDepositAddress(
      {required SubstrateRPC provider,
      required OpenSwappingChannelOperation operation,
      required SubstrateAddress? source,
      required SubstratePrivateKey signer,
      String? genesisHash,
      String? blockHash,
      int? nonce}) async {
    final payload = await buildOperationPayload(
        provider: provider,
        operation: operation,
        source: source ?? signer.toAddress(),
        blockHash: blockHash,
        genesisHash: genesisHash,
        nonce: nonce);
    final extrinsic = signPayload(payload: payload, signer: signer);
    final submit =
        await submitExtrinsicAndWatch(provider: provider, extrinsic: extrinsic);
    final depositEvents = submit.events.where(
        (e) => e.method == _ChainFlipApiConst.depositAddressReadyMethodName);
    for (final e in depositEvents) {
      final Map<String, dynamic> eventInput = (e.input as Map).cast();
      final depositAddress = CfApiUtils.encodeVariantAddress(
          result: eventInput["deposit_address"], network: network);
      final destinationAddress = CfApiUtils.encodeVariantAddress(
          result: eventInput["destination_address"], network: network);
      if (destinationAddress.item1 == operation.destination.addressStr &&
          destinationAddress.item2 == operation.destination.chain.chain &&
          depositAddress.item2 == operation.source.chain) {
        return BrokerRequestSwapDepositAddressResponse(
            address: depositAddress.item1,
            issuedBlock: submit.blockNumber,
            channelId: IntUtils.parse(eventInput["channel_id"]),
            sourceChainExpiryBlock:
                BigintUtils.parse(eventInput["source_chain_expiry_block"]),
            channelOpeningFee:
                BigintUtils.parse(eventInput["channel_opening_fee"]));
      }
    }
    throw DartChainFlipException(
      "Unable to dectect ${_ChainFlipApiConst.depositAddressReadyMethodName} event.",
    );
  }

  Future<LiquidityDepositAddressResponse> requestLiquidityDepositAddress(
      {required SubstrateRPC provider,
      required LiquidityDepositAddressOperation operation,
      required SubstrateAddress? source,
      required SubstratePrivateKey signer,
      String? genesisHash,
      String? blockHash,
      int? nonce}) async {
    final payload = await buildOperationPayload(
        provider: provider,
        operation: operation,
        source: source ?? signer.toAddress(),
        blockHash: blockHash,
        genesisHash: genesisHash,
        nonce: nonce);
    final extrinsic = signPayload(payload: payload, signer: signer);
    final submit =
        await submitExtrinsicAndWatch(provider: provider, extrinsic: extrinsic);

    final depositEvents = submit.events.firstWhere(
        (e) =>
            e.method ==
            _ChainFlipApiConst.liquidityDepositAddressReadyMethodName,
        orElse: () => throw DartChainFlipException(
            "Unable to dectect ${_ChainFlipApiConst.depositAddressReadyMethodName} event."));
    final Map<String, dynamic> eventInput = (depositEvents.input as Map).cast();
    final asset = CfApiUtils.getVariantAssets(eventInput["asset"]);
    final destinationAddress = CfApiUtils.encodeVariantAddress(
        result: eventInput["deposit_address"], network: network);
    if (asset.asset == operation.asset.asset) {
      return LiquidityDepositAddressResponse(
          depositAddress: destinationAddress.item1,
          asset: asset.asset,
          channelId: BigintUtils.parse(eventInput["channel_id"]),
          channelOpeningFee:
              BigintUtils.parse(eventInput["channel_opening_fee"]),
          boostFee: IntUtils.parse(eventInput["boost_fee"]),
          depositChainExpiryBlock:
              BigintUtils.parse(eventInput["deposit_chain_expiry_block"]),
          address: SubstrateAddress.fromBytes(
              (eventInput["account_id"] as List).cast()));
    }
    throw DartChainFlipException(
        "Unable to dectect ${_ChainFlipApiConst.liquidityDepositAddressReadyMethodName} event.");
  }

  Stream<StramBlockResponse> _findTransactionStream(
      {Duration retryInterval = const Duration(seconds: 4),
      required int blockId,
      required String extrinsic,
      required SubstrateRPC provider,
      int maxRetryEachBlock = 5,
      int blockCount = 20}) {
    final controller = StreamController<StramBlockResponse>();
    void closeController() {
      if (!controller.isClosed) {
        controller.close();
      }
    }

    void startFetching() async {
      int id = blockId;
      int retry = maxRetryEachBlock;
      int count = blockCount;
      while (!controller.isClosed) {
        try {
          final result = await _lockupBlock(
              blockId: id, provider: provider, extrinsic: extrinsic);
          id++;
          count--;
          retry = maxRetryEachBlock;
          if (result != null) {
            controller.add(result);
            closeController();
          } else if (count <= 0) {
            controller.addError(DartChainFlipException(
                "Failed to fetch the block within the last ${blockCount} blocks."));
            closeController();
          }
        } on DartChainFlipException catch (e) {
          controller.addError(e);
          controller.close();
        } catch (_) {
          retry--;
          if (retry <= 0) {
            controller.addError(DartChainFlipException(
                "Failed to fetch the transaction within the allotted time."));
            closeController();
          }
        }
        await Future.delayed(retryInterval);
      }
    }

    startFetching();
    return controller.stream.asBroadcastStream(onCancel: (e) {
      controller.close();
      print("controller has been closed");
    });
  }

  Future<StramBlockResponse> submitExtrinsicAndWatch(
      {required SubstrateRPC provider,
      required Extrinsic extrinsic,
      int maxRetryEachBlock = 5}) async {
    final blockHeader =
        await provider.request(SubstrateRPCChainChainGetHeader());
    final ext = extrinsic.toHex(prefix: "0x");
    final transactionHash =
        await provider.request(SubstrateRPCAuthorSubmitExtrinsic(ext));
    print("transactionhash $transactionHash");
    final completer = Completer<StramBlockResponse>();
    StreamSubscription<StramBlockResponse>? stream;
    try {
      stream = _findTransactionStream(
              blockId: blockHeader.number,
              provider: provider,
              extrinsic: ext,
              maxRetryEachBlock: maxRetryEachBlock)
          .listen((e) async {
        print("find events ${e.events.length}");
        completer.complete(e);
      }, onDone: () {
        print("on n done called!");
      }, onError: (e) {
        if (completer.isCompleted) return;
        if (e is DartChainFlipException) {
          completer.completeError(DartChainFlipException(e.message,
              details: {"tx": transactionHash, ...e.details ?? {}}));
        } else {
          completer.completeError(DartChainFlipException(
              "Failed to fetch the transaction. $transactionHash",
              details: {"tx": transactionHash, "stack": e.toString()}));
        }
      });
      return await completer.future;
    } finally {
      stream?.cancel();
      stream = null;
    }
  }

  Future<StramBlockResponse?> _lockupBlock({
    required int blockId,
    required SubstrateRPC provider,
    required String extrinsic,
  }) async {
    final blockHash = await provider
        .request(SubstrateRPCChainGetBlockHash<String?>(number: blockId));
    if (blockHash == null) {
      throw TypeError();
    }
    try {
      final block = await provider
          .request(SubstrateRPCChainGetBlock(atBlockHash: blockHash));
      final index = block.block.extrinsics.indexOf(extrinsic);
      if (index < 0) return null;
      final events =
          await api.getSystemEvents(provider, atBlockHash: blockHash);
      return StramBlockResponse(
          events: events.where((e) => e.applyExtrinsic == index).toList(),
          block: blockHash,
          extrinsic: extrinsic,
          blockNumber: blockId);
    } catch (e) {
      throw DartChainFlipException("Somthing wrong when parsing block",
          details: {"block": blockHash, "stack": e.toString()});
    }
  }
}

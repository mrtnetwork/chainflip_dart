import 'package:chain_flip/src/provider/models/rpc/response_types.dart';
import 'package:chain_flip/src/sdk/api/cf/impl/substrate.dart';
import 'package:chain_flip/src/sdk/chain/types/chain_flip_networks.dart';
import 'package:chain_flip/src/sdk/api/cf/models/models.dart';
import 'package:chain_flip/src/sdk/api/cf/impl/eth.dart';
import 'package:chain_flip/src/sdk/api/cf/operations/evm.dart';
import 'package:chain_flip/src/sdk/api/cf/operations/substrate.dart';
import 'package:on_chain/on_chain.dart';
import 'package:polkadot_dart/polkadot_dart.dart';

abstract class CfApiCore {
  abstract final CfNetwork network;
}

abstract class CfEvmApiCore extends CfApiCore {
  Future<ETHTransactionBuilder> signTransaction(
      {required ETHTransactionBuilder transaction,
      required ETHPrivateKey signer});
  Future<String> sendTransaction(
      {required ETHTransactionBuilder transaction, required EVMRPC rpc});
  Future<TransactionReceipt> sendAndSubmitTransaction(
      {required ETHTransactionBuilder transaction, required EVMRPC rpc});
  Future<T> callContract<T>(
      {required AbiFunctionFragment function,
      required List<dynamic> input,
      required EVMRPC rpc,
      required ETHAddress contractAddress,
      ETHAddress? from});
  Future<ETHTransactionBuilder> buildEthereumTransaction(
      {required ETHAddress from,
      required ETHAddress to,
      required BigInt chainId,
      required List<int> data,
      required EVMRPC rpc,
      BigInt? nativeAmount,
      EVMTransactionParams? params});
  Future<RESULT> callFlipContract<RESULT>(
      {required EvmFlipContractOperation<RESULT> operation,
      required EVMRPC rpc,
      ETHAddress? flipContractAddress,
      ETHAddress? from});
  Future<RESULT> callStateChainGatewayContract<RESULT>(
      {required EvmStateChainGatewayCallOperation<RESULT> operation,
      required EVMRPC rpc,
      ETHAddress? stateChainGatewayAddress,
      ETHAddress? from});
  Future<ETHTransactionBuilder> buildContractTransaction({
    required AbiFunctionFragment function,
    required List<dynamic> functionInputs,
    required EVMRPC rpc,
    required ETHAddress account,
    required ETHAddress contractAddress,
    EVMTransactionParams? params,
    BigInt? chainId,
    BigInt? nativeAmount,
  });
  Future<ETHTransactionBuilder> buildStateChainGatewayContractTransaction({
    required EvmStateChainGatewayExcuteOperation operation,
    required EVMRPC rpc,
    required ETHAddress account,
    EVMTransactionParams? params,
    ETHAddress? stateChainGatewayAddress,
    BigInt? chainId,
    BigInt? nativeAmount,
  });
  Future<ETHTransactionBuilder> buildVaultContractTransaction({
    required EvmVaultExcuteOperation operation,
    required EVMRPC rpc,
    required ETHAddress account,
    EVMTransactionParams? params,
    VaultContractChain? vaultChain,
    ETHAddress? vaultContractAddress,
    BigInt? chainId,
    BigInt? nativeAmount,
  });
  Future<ETHTransactionBuilder> buildFlipContractTransaction({
    required EvmFlipContractExcuteOperation operation,
    required EVMRPC rpc,
    required ETHAddress account,
    EVMTransactionParams? params,
    ETHAddress? flipContractAddress,
    BigInt? chainId,
    BigInt? nativeAmount,
  });
}

abstract class CfSubstrateApiCore implements CfApiCore {
  abstract final MetadataApi api;

  Future<int> getAccountNonce(
      {required SubstrateRPC provider, required SubstrateAddress source});
  Extrinsic signPayload(
      {required LegacyTransactionPayload payload,
      required SubstratePrivateKey signer});

  Future<LegacyTransactionPayload> buildOperationPayload(
      {required SubstrateRPC provider,
      required ChainFlipSubstrateOperation operation,
      required SubstrateAddress source,
      String? genesisHash,
      String? blockHash,
      int? nonce});

  Future<String> submitExtrinsic(
      {required SubstrateRPC provider, required Extrinsic extrinsic});

  Future<BrokerRequestSwapDepositAddressResponse> requestSwapDepositAddress(
      {required SubstrateRPC provider,
      required OpenSwappingChannelOperation operation,
      required SubstrateAddress? source,
      required SubstratePrivateKey signer,
      String? genesisHash,
      String? blockHash,
      int? nonce});

  Future<LiquidityDepositAddressResponse> requestLiquidityDepositAddress(
      {required SubstrateRPC provider,
      required LiquidityDepositAddressOperation operation,
      required SubstrateAddress? source,
      required SubstratePrivateKey signer,
      String? genesisHash,
      String? blockHash,
      int? nonce});

  Future<StramBlockResponse> submitExtrinsicAndWatch(
      {required SubstrateRPC provider,
      required Extrinsic extrinsic,
      int maxRetryEachBlock = 5});
}

abstract class CfFullApiCore implements CfEthereumApiImpl, CfSubstrateApiCore {}

class CfSubstrateApi extends CfSubstrateApiCore with SubstrateApiImpl {
  final MetadataApi api;
  final CfNetwork network;
  CfSubstrateApi({required this.api, required this.network});
}

class CfEvmApi extends CfEvmApiCore with CfEthereumApiImpl {
  final CfNetwork network;
  CfEvmApi(this.network);
}

class CfFullApi extends CfFullApiCore with SubstrateApiImpl, CfEthereumApiImpl {
  final CfNetwork network;
  @override
  final MetadataApi api;
  CfFullApi({required this.network, required this.api});
}

class ChainFlipSwapMethods {
  final String name;
  final String url;
  const ChainFlipSwapMethods._({required this.name, required this.url});
  static const ChainFlipSwapMethods quote =
      ChainFlipSwapMethods._(name: "quote", url: "/quote");
  static const ChainFlipSwapMethods quoteV2 =
      ChainFlipSwapMethods._(name: "quoteV2", url: "/v2/quote");
  static const ChainFlipSwapMethods swap =
      ChainFlipSwapMethods._(name: "swap", url: "/swaps/:id");
  static const ChainFlipSwapMethods swapV2 =
      ChainFlipSwapMethods._(name: "swap", url: "/v2/swaps/:id");
}

import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/provider/core/swap.dart';
import 'package:chain_flip/src/provider/models/swap.dart';

class ChainFlipRequestSwapStatus
    extends ChainFlipRequestParam<VaultSwapResponse2, Map<String, dynamic>> {
  final String id;
  const ChainFlipRequestSwapStatus(this.id);
  @override
  Map<String, String?>? get queryParameters => {};

  @override
  String get method => ChainFlipSwapMethods.swap.url;

  @override
  List<String> get pathParameters => [id];

  @override
  VaultSwapResponse2 onResonse(Map<String, dynamic> result) {
    print("result $result");
    return VaultSwapResponse2.fromJson(result);
  }
}

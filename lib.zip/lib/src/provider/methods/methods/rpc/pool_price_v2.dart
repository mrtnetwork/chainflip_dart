import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/provider/models/rpc/response_types.dart';
import 'package:chain_flip/src/sdk/chain/types/asset_and_chain.dart';

class ChainFlipRPCRequestPoolPricev2 extends ChainFlipRPCRequestParam<
    PoolPriceV2Response, Map<String, dynamic>> {
  final UncheckedAssetAndChain baseAsset;
  final UncheckedAssetAndChain quoteAsset;
  const ChainFlipRPCRequestPoolPricev2(
      {required this.baseAsset, required this.quoteAsset});

  @override
  List get params => [baseAsset.toJson(), quoteAsset.toJson()];

  @override
  String get method => "cf_pool_price_v2";

  @override
  PoolPriceV2Response onResonse(Map<String, dynamic> result) {
    return PoolPriceV2Response.fromJson(result);
  }
}

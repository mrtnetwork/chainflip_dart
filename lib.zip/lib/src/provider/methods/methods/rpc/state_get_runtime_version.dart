import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/provider/models/rpc/response_types.dart';

class ChainFlipRPCRequestStateGetRuntimeVersion
    extends ChainFlipRPCRequestParam<RuntimeVersionResponse,
        Map<String, dynamic>> {
  @override
  String get method => "state_getRuntimeVersion";

  @override
  RuntimeVersionResponse onResonse(Map<String, dynamic> result) {
    return RuntimeVersionResponse.fromJson(result);
  }
}

import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/provider/models/rpc/response_types.dart';

class ChainFlipRPCRequestIngressEgressEnvironment
    extends ChainFlipRPCRequestParam<IngressEgressEnvironment,
        Map<String, dynamic>> {
  @override
  String get method => "cf_ingress_egress_environment";

  @override
  IngressEgressEnvironment onResonse(Map<String, dynamic> result) {
    return IngressEgressEnvironment.fromJson(result);
  }
}

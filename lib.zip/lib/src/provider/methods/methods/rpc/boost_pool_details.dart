import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/provider/models/rpc/response_types.dart';
import 'package:chain_flip/src/sdk/chain/types/asset_and_chain.dart';

class ChainFlipRPCRequestBoostPoolDetails
    extends ChainFlipRPCRequestParam<List<BoostPoolDetailsResponse>, List> {
  final UncheckedAssetAndChain? asset;
  const ChainFlipRPCRequestBoostPoolDetails({this.asset});
  @override
  List get params => [asset?.toJson()];
  @override
  String get method => "cf_boost_pool_details";

  @override
  List<BoostPoolDetailsResponse> onResonse(List result) {
    return result.map((e) => BoostPoolDetailsResponse.fromJson(e)).toList();
  }
}

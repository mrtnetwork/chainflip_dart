import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/provider/models/rpc/response_types.dart';

class ChainFlipRPCRequestSwappingEnvironment extends ChainFlipRPCRequestParam<
    SwappingEnvironment, Map<String, dynamic>> {
  @override
  String get method => "cf_swapping_environment";

  @override
  SwappingEnvironment onResonse(Map<String, dynamic> result) {
  print("Result $result");
    return SwappingEnvironment.fromJson(result);
  }
}

import 'package:chain_flip/src/provider/core/core.dart';

class ChainFlipRPCRequestStateGetMetadata
    extends ChainFlipRPCRequestParam<String, String> {
  @override
  String get method => "state_getMetadata";
}

import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/provider/models/rpc/response_types.dart';

class ChainFlipRPCRequestPoolsEnvironment
    extends ChainFlipRPCRequestParam<PoolsEnvironment, Map<String, dynamic>> {
  @override
  String get method => "cf_pools_environment";

  @override
  PoolsEnvironment onResonse(Map<String, dynamic> result) {
    return PoolsEnvironment.fromJson(result);
  }
}

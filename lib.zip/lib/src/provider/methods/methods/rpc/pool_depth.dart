import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/provider/models/rpc/response_types.dart';
import 'package:chain_flip/src/provider/models/rpc/tick_range.dart';
import 'package:chain_flip/src/sdk/chain/types/asset_and_chain.dart';

class ChainFlipRPCRequestPoolDepth
    extends ChainFlipRPCRequestParam<PoolDepth?, Map<String, dynamic>?> {
  final AssetAndChain fromAsset;
  final AssetAndChain toAsset;
  final TickRange tickRange;
  const ChainFlipRPCRequestPoolDepth(
      {required this.fromAsset,
      required this.toAsset,
      required this.tickRange});

  @override
  List get params => [fromAsset.toJson(), toAsset.toJson(), tickRange.toJson()];

  @override
  String get method => "cf_pool_depth";

  @override
  PoolDepth? onResonse(Map<String, dynamic>? result) {
    if (result == null) return null;
    return PoolDepth.fromJson(result);
  }
}

import 'package:blockchain_utils/utils/numbers/utils/bigint_utils.dart';

class Validator {
  final String role;
  final BigInt flipBalance;
  final BigInt bond;
  final int lastHeartbeat;
  final int reputationPoints;
  final List<int> keyholderEpochs;
  final bool isCurrentAuthority;
  final bool isCurrentBackup;
  final bool isQualified;
  final bool isOnline;
  final bool isBidding;
  final String? boundRedeemAddress;
  final int? apyBp;
  final Map<String, BigInt> restrictedBalances;

  Validator({
    required this.role,
    required this.flipBalance,
    required this.bond,
    required this.lastHeartbeat,
    required this.reputationPoints,
    required this.keyholderEpochs,
    required this.isCurrentAuthority,
    required this.isCurrentBackup,
    required this.isQualified,
    required this.isOnline,
    required this.isBidding,
    this.boundRedeemAddress,
    this.apyBp,
    required this.restrictedBalances,
  });

  factory Validator.fromJson(Map<String, dynamic> json) {
    return Validator(
      role: json['role'] as String,
      flipBalance: BigintUtils.parse(json['flip_balance']),
      bond: BigintUtils.parse(json['bond']),
      lastHeartbeat: json['last_heartbeat'],
      reputationPoints: json['reputation_points'],
      keyholderEpochs: List<int>.from(json['keyholder_epochs']),
      isCurrentAuthority: json['is_current_authority'],
      isCurrentBackup: json['is_current_backup'],
      isQualified: json['is_qualified'],
      isOnline: json['is_online'],
      isBidding: json['is_bidding'],
      boundRedeemAddress: json['bound_redeem_address'],
      apyBp: json['apy_bp'],
      restrictedBalances: (json['restricted_balances'] as Map?)
              ?.map((k, v) => MapEntry(k, BigintUtils.parse(v))) ??
          {},
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'role': role,
      'flip_balance': flipBalance.toString(),
      'bond': bond.toString(),
      'last_heartbeat': lastHeartbeat,
      'reputation_points': reputationPoints,
      'keyholder_epochs': keyholderEpochs,
      'is_current_authority': isCurrentAuthority,
      'is_current_backup': isCurrentBackup,
      'is_qualified': isQualified,
      'is_online': isOnline,
      'is_bidding': isBidding,
      'bound_redeem_address': boundRedeemAddress,
      'apy_bp': apyBp,
      'restricted_balances':
          restrictedBalances.map((k, v) => MapEntry(k, v.toString())),
    };
  }
}


class Unregistered {
  final String role;
  final BigInt flipBalance;
  Unregistered({
    required this.role,
    required this.flipBalance,
  });

  factory Unregistered.fromJson(Map<String, dynamic> json) {
    return Unregistered(
      role: json['role'] as String,
      flipBalance: BigintUtils.parse(json['flip_balance']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'role': role,
      'flip_balance': flipBalance.toString()
    };
  }
}
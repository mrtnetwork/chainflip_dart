class AffiliateBroker{
final String account;
final int commissionBps;
const AffiliateBroker({required this.account,required this.commissionBps});
}
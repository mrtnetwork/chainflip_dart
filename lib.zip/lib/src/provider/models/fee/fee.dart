// type Fee<T> = {
//   type: T;
//   chain: Chain;
//   asset: Asset;
//   amount: string;
// };

import 'package:chain_flip/src/exception/exception.dart';
import 'package:chain_flip/src/provider/models/fee/fee_type.dart';

abstract class ChainFlipFee {
  final ChainFlipFeeType type;
  final String chain;
  final String asset;
  final String amount;
  const ChainFlipFee(
      {required this.type,
      required this.chain,
      required this.asset,
      required this.amount});

  Map<String, dynamic> toJson() {
    return {
      "type": type.type,
      "chain": chain,
      "asset": asset,
      "amount": amount
    };
  }

  factory ChainFlipFee.fromJson(Map<String, dynamic> json) {
    final type = ChainFlipFeeType.fromName(json["type"]);
    switch (type) {
      case ChainFlipFeeType.liquidity:
        return ChainFlipPoolFee.fromJson(json);
      default:
        return ChainFlipSwapFee.fromJson(json);
    }
  }
}

class ChainFlipSwapFee extends ChainFlipFee {
  ChainFlipSwapFee._(
      {required ChainFlipFeeType type,
      required String chain,
      required String asset,
      required String amount})
      : super(type: type, chain: chain, asset: asset, amount: amount);
  factory ChainFlipSwapFee(
      {required ChainFlipFeeType type,
      required String chain,
      required String asset,
      required String amount}) {
    if (type == ChainFlipFeeType.liquidity) {
      throw DartChainFlipException("Invalid swap Fee type.",
          details: {"type": type.type});
    }
    return ChainFlipSwapFee._(
        type: type, chain: chain, asset: asset, amount: amount);
  }
  // Converts JSON map to ChainFlipSwapFee instance
  factory ChainFlipSwapFee.fromJson(Map<String, dynamic> json) {
    // print("fee json $json");
    return ChainFlipSwapFee(
      type: ChainFlipFeeType.fromName(json['type']),
      chain: json['chain'],
      asset: json['asset'],
      amount: json['amount'],
    );
  }
}

class ChainFlipPoolFee extends ChainFlipFee {
  ChainFlipPoolFee(
      {required String chain, required String asset, required String amount})
      : super(
            type: ChainFlipFeeType.liquidity,
            chain: chain,
            asset: asset,
            amount: amount);

  factory ChainFlipPoolFee.fromJson(Map<String, dynamic> json) {
    return ChainFlipPoolFee(
      chain: json['chain'],
      asset: json['asset'],
      amount: json['amount'],
    );
  }
}

import 'package:blockchain_utils/blockchain_utils.dart';

class DartChainFlipException extends BlockchainUtilsException {
  DartChainFlipException(String message, {Map<String, dynamic>? details})
      : super(message, details: details);
}

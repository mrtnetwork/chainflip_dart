import 'package:blockchain_utils/utils/string/string.dart';
import 'package:chain_flip/src/exception/exception.dart';
import 'package:chain_flip/src/provider/utils/utils.dart';

enum HTTPRequestType { post, get }

abstract class ChainFlipRequestParams {
  abstract final String method;
}

abstract class ChainFlipRequestParam<RESULT, RESPONSE>
    implements ChainFlipRequestParams {
  const ChainFlipRequestParam();
  List<String> get pathParameters => [];
  Map<String, String?>? get queryParameters => null;

  RESULT onResonse(RESPONSE result) {
    return result as RESULT;
  }

  ChainFlipRequestDetails toRequest(int v) {
    // throw UnimplementedError();
    final pathParams = ChainFlipProviderUtils.extractParams(method);
    if (pathParams.length != pathParameters.length) {
      throw DartChainFlipException("Invalid Path Parameters.", details: {
        "pathParams": pathParameters,
        "ExceptedPathParametersLength": pathParams.length
      });
    }
    String params = method;
    for (int i = 0; i < pathParams.length; i++) {
      params = params.replaceFirst(pathParams[i], pathParameters[i]);
    }
    final queryParams = Map<String, String?>.from(this.queryParameters ?? {})
      ..removeWhere((k, v) => v == null);
    // final Map<String, String?> queryParams =
    //     Map<String, String?>.from(this.queryParameters ?? {});
    if (queryParams.isNotEmpty) {
      params = Uri(path: params, queryParameters: queryParams)
          .normalizePath()
          .toString();
    }
    return ChainFlipRequestDetails(id: v, pathParams: params);
  }
}

/// An abstract class representing post request parameters for blockfrost (ADA) API calls.
abstract class ChainFlipRPCRequestParam<RESULT, RESPONSE>
    extends ChainFlipRequestParam<RESULT, RESPONSE> {
  const ChainFlipRPCRequestParam();
  // abstract final Object body;
  List<dynamic> get params => [];
  final Map<String, String>? header = null;

  @override
  ChainFlipRequestDetails toRequest(int v) {
    return ChainFlipRequestDetails(
        id: v,
        requestType: HTTPRequestType.post,
        pathParams: method,
        body: StringUtils.fromJson({
          "jsonrpc": '2.0',
          "id": v.toString(),
          "method": method,
          "params": params
        }));
  }
}

class ChainFlipRequestDetails {
  const ChainFlipRequestDetails(
      {required this.id,
      this.pathParams,
      this.header = const {},
      this.requestType = HTTPRequestType.get,
      this.body});

  ChainFlipRequestDetails copyWith({
    int? id,
    String? pathParams,
    HTTPRequestType? requestType,
    Map<String, String>? header,
    String? body,
  }) {
    return ChainFlipRequestDetails(
      id: id ?? this.id,
      pathParams: pathParams ?? this.pathParams,
      requestType: requestType ?? this.requestType,
      header: header ?? this.header,
      body: body ?? this.body,
    );
  }

  /// Unique identifier for the request.
  final int id;

  /// URL path parameters
  final String? pathParams;

  final HTTPRequestType requestType;

  final Map<String, String> header;

  final String? body;

  /// Generates the complete request URL by combining the base URI and method-specific URI.
  String url(String uri, {String? brokerUrl}) {
    if (pathParams == "broker_requestSwapDepositAddress") {
      if (brokerUrl == null) {
        throw UnimplementedError(
            "brokerUrl must be set for broker request. `broker_requestSwapDepositAddress`");
      }
      uri = brokerUrl;
    }
    if (requestType == HTTPRequestType.post) {
      return "$uri/";
    }
    String url = uri;
    // if (!url.contains(version)) {
    //   if (url.endsWith("/")) {
    //     url = url + version;
    //   } else {
    //     url = "$url/$version";
    //   }
    // }
    if (url.endsWith("/")) {
      url = url.substring(0, url.length - 1);
    }
    print("$url$pathParams");
    return "$url$pathParams";
  }
}

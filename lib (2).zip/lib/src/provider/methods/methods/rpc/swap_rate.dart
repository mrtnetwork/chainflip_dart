import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/provider/models/rpc/response_types.dart';
import 'package:chain_flip/src/sdk/chain/types/asset_and_chain.dart';

class ChainFlipRPCRequestSwapRate
    extends ChainFlipRPCRequestParam<SwapRateResponse, Map<String, dynamic>> {
  final UncheckedAssetAndChain fromAsset;
  final UncheckedAssetAndChain toAsset;
  final String amount;
  const ChainFlipRPCRequestSwapRate(
      {required this.fromAsset, required this.toAsset, required this.amount});

  @override
  List get params => [fromAsset.toJson(), toAsset.toJson(), amount];

  @override
  String get method => "cf_swap_rate";

  @override
  SwapRateResponse onResonse(Map<String, dynamic> result) {
    return SwapRateResponse.fromJson(result);
  }
}

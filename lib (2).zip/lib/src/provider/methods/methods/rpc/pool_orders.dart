import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/provider/models/rpc/response_types.dart';
import 'package:chain_flip/src/sdk/chain/types/asset_and_chain.dart';

class ChainFlipRPCRequestPoolOrders
    extends ChainFlipRPCRequestParam<PoolOrdersResponse, Map<String, dynamic>> {
  final UncheckedAssetAndChain fromAsset;
  final UncheckedAssetAndChain toAsset;
  final String? accountId;
  const ChainFlipRPCRequestPoolOrders(
      {required this.fromAsset, required this.toAsset, this.accountId});

  @override
  List get params => [fromAsset.toJson(), toAsset.toJson(), accountId];

  @override
  String get method => "cf_pool_orders";

  @override
  PoolOrdersResponse onResonse(Map<String, dynamic> result) {
    return PoolOrdersResponse.fromJson(result);
  }
}

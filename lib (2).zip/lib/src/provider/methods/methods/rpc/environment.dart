import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/provider/models/rpc/response_types.dart';

class ChainFlipRPCRequestEnvironment
    extends ChainFlipRPCRequestParam<Environment, Map<String, dynamic>> {
  @override
  String get method => "cf_environment";

  @override
  Environment onResonse(Map<String, dynamic> result) {
    return Environment.fromJson(result);
  }
}

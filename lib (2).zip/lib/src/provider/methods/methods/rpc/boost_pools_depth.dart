import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/provider/models/rpc/response_types.dart';

class ChainFlipRPCRequestBoostPoolsDepth
    extends ChainFlipRPCRequestParam<List<BoostPoolDepthResponse>, List> {
  @override
  String get method => "cf_boost_pools_depth";
  @override
  List<BoostPoolDepthResponse> onResonse(List result) {
  print("result $result");
    return result.map((e) => BoostPoolDepthResponse.fromJson(e)).toList();
  }
}

import 'package:chain_flip/src/provider/core/core.dart';

class ChainFlipRPCRequestAccountsInfo
    extends ChainFlipRPCRequestParam {
  final String accountId;
  const ChainFlipRPCRequestAccountsInfo(this.accountId);
  @override
  List get params => [accountId];
  @override
  String get method => "cf_account_info";

}

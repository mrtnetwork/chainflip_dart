import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/sdk/chain/types/asset_and_chain.dart';

class ChainFlipRPCRequestSupportAssets extends ChainFlipRPCRequestParam<
    List<AssetAndChain>, List<Map<String, dynamic>>> {
  @override
  String get method => "cf_supported_assets";

  @override
  List<AssetAndChain> onResonse(List<Map<String, dynamic>> result) {
    return result.map((e) => AssetAndChain.fromJson(e)).toList();
  }
}

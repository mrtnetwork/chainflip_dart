import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/provider/models/rpc/response_types.dart';
import 'package:chain_flip/src/provider/models/rpc/types.dart';
import 'package:chain_flip/src/sdk/chain/types/asset_and_chain.dart';

class ChainFlipRPCRequestBrokerRequestSwapDepositAddress
    extends ChainFlipRPCRequestParam<BrokerRequestSwapDepositAddressResponse,
        Map<String, dynamic>> {
  final UncheckedAssetAndChain sourceAsset;
  final UncheckedAssetAndChain destinationAsset;
  final String destinationAddress;
  final int? brokerCommission;
  final CCMMetadata? ccmMetadata;
  final int? boostFee;
  final DCAParams? dcaParams;
  final FillOrKillParams? fillOrKillParams;
  final AffiliateFeesParams? affiliateFees;
  const ChainFlipRPCRequestBrokerRequestSwapDepositAddress(
      {required this.sourceAsset,
      required this.destinationAsset,
      required this.destinationAddress,
      required this.brokerCommission,
      this.ccmMetadata,
      this.boostFee,
      this.dcaParams,
      this.fillOrKillParams,
      this.affiliateFees});
  @override
  List get params => [
        sourceAsset,
        destinationAsset,
        destinationAddress,
        brokerCommission,
        ccmMetadata?.toJson(),
        boostFee,
        affiliateFees?.toJson(),
        fillOrKillParams?.toJson(),
        dcaParams?.toJson()
      ];
  @override
  String get method => "broker_requestSwapDepositAddress";

  @override
  BrokerRequestSwapDepositAddressResponse onResonse(Map<String, dynamic> result) {
    print(result);
    return BrokerRequestSwapDepositAddressResponse.fromJson(result);
  }
}

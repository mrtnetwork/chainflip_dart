import 'package:chain_flip/src/provider/core/core.dart';

class ChainFlipRPCRequestChainGetBlockHash
    extends ChainFlipRPCRequestParam<String, String> {
  final int? blockHeight;
  const ChainFlipRPCRequestChainGetBlockHash({this.blockHeight});
  @override
  String get method => "chain_getBlockHash";
  @override
  List get params => [blockHeight];
}

import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/provider/models/rpc/response_types.dart';
import 'package:chain_flip/src/sdk/chain/types/asset_and_chain.dart';

class ChainFlipRPCRequestBoostPoolPendingFees
    extends ChainFlipRPCRequestParam<List<BoostPoolPendingFeesResponse>, List> {
  final UncheckedAssetAndChain? asset;
  const ChainFlipRPCRequestBoostPoolPendingFees({this.asset});
  @override
  List get params => [asset?.toJson()];
  @override
  String get method => "cf_boost_pool_pending_fees";

  @override
  List<BoostPoolPendingFeesResponse> onResonse(List result) {
    return result.map((e) => BoostPoolPendingFeesResponse.fromJson(e)).toList();
  }
}

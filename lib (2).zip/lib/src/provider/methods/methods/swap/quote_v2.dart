import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:chain_flip/src/provider/core/core.dart';
import 'package:chain_flip/src/provider/core/swap.dart';
import 'package:chain_flip/src/provider/models/affiliate_broker.dart';
import 'package:chain_flip/src/provider/models/quote.dart';

class ChainFlipRequestQuoteV2
    extends ChainFlipRequestParam<List<QuoteQueryResponse>, List> {
  ChainFlipRequestQuoteV2(
      {required this.srcChain,
      required this.srcAsset,
      required this.destChain,
      required this.destAsset,
      required this.amount,
      this.brokerCommissionBps,
      List<AffiliateBroker>? affiliateBrokers})
      : affiliateBrokers = affiliateBrokers?.immutable;
  final String srcChain;
  final String srcAsset;
  final String destChain;
  final String destAsset;
  final String amount;
  final int? brokerCommissionBps;
  final List<AffiliateBroker>? affiliateBrokers;
  @override
  Map<String, String?>? get queryParameters => {
        "amount": amount,
        "srcChain": srcChain,
        "srcAsset": srcAsset,
        "destChain": destChain,
        "destAsset": destAsset,
        "brokerCommissionBps": brokerCommissionBps?.toString(),
        "dcaEnabled": 'false',
      };

  @override
  String get method => ChainFlipSwapMethods.quoteV2.url;

  @override
  List<String> get pathParameters => [];
  @override
  List<QuoteQueryResponse> onResonse(List result) {
    return result.map((e) => QuoteQueryResponse.fromJson(e)).toList();
  }
}

import 'package:chain_flip/src/provider/models/fee/fee.dart';
import 'package:chain_flip/src/sdk/chain/types/asset_and_chain.dart';

class PoolInfo {
  final UncheckedAssetAndChain baseAsset;
  final UncheckedAssetAndChain quoteAsset;
  final ChainFlipPoolFee fee;

  const PoolInfo({
    required this.baseAsset,
    required this.quoteAsset,
    required this.fee,
  });

  factory PoolInfo.fromJson(Map<String, dynamic> json) {
    return PoolInfo(
      baseAsset: UncheckedAssetAndChain.fromJson(json['baseAsset']),
      quoteAsset: UncheckedAssetAndChain.fromJson(json['quoteAsset']),
      fee: ChainFlipPoolFee.fromJson(json['fee']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'baseAsset': baseAsset.toJson(),
      'quoteAsset': quoteAsset.toJson(),
      'fee': fee.toJson(),
    };
  }
}

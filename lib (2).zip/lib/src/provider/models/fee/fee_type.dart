import 'package:chain_flip/src/exception/exception.dart';

class ChainFlipFeeType {
  final String type;

  const ChainFlipFeeType._(this.type);

  static const ChainFlipFeeType network = ChainFlipFeeType._('NETWORK');
  static const ChainFlipFeeType ingress = ChainFlipFeeType._('INGRESS');
  static const ChainFlipFeeType egress = ChainFlipFeeType._('EGRESS');
  static const ChainFlipFeeType broker = ChainFlipFeeType._('BROKER');
  static const ChainFlipFeeType boost = ChainFlipFeeType._('BOOST');
  static const ChainFlipFeeType liquidity = ChainFlipFeeType._("LIQUIDITY");

  static List<ChainFlipFeeType> get values =>
      [network, ingress, egress, broker, boost, liquidity];

  static ChainFlipFeeType fromName(String? name) {
    return values.firstWhere((e) => e.type == name,
        orElse: () => throw DartChainFlipException("fee type not found.",
            details: {"type": name}));
  }
}

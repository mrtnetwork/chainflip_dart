import 'package:chain_flip/src/exception/exception.dart';
import 'package:chain_flip/src/provider/models/fee/fee.dart';
import 'package:chain_flip/src/provider/models/pool/pool_info.dart';

class QuoteType {
  final String name;
  const QuoteType._(this.name);
  static const QuoteType regular = QuoteType._("REGULAR");
  static const QuoteType dca = QuoteType._("DCA");
  static List<QuoteType> get values => [regular, dca];
  static QuoteType fromName(String? name) {
    return values.firstWhere(
      (e) => e.name == name,
      orElse: () => throw DartChainFlipException("Quote type not found.",
          details: {"type": name}),
    );
  }
}

class DCAParams {
  final int numberOfChunks;
  final int chunkIntervalBlocks;
  const DCAParams(
      {required this.numberOfChunks, required this.chunkIntervalBlocks});
  factory DCAParams.fromJson(Map<String, dynamic> json) {
    return DCAParams(
        numberOfChunks: json["numberOfChunks"],
        chunkIntervalBlocks: json["chunkIntervalBlocks"]);
  }

  Map<String, dynamic> toJson() {
    return {
      "numberOfChunks": numberOfChunks,
      "chunkIntervalBlocks": chunkIntervalBlocks
    };
  }
}

class QuoteDetails {
  final String? intermediateAmount;
  final String egressAmount;
  final List<ChainFlipSwapFee> includedFees;
  final List<PoolInfo> poolInfo;
  final bool? lowLiquidityWarning;
  final double estimatedDurationSeconds;
  final String estimatedPrice;
  final QuoteType type;
  final DCAParams? dcaParams;

  const QuoteDetails({
    required this.intermediateAmount,
    required this.egressAmount,
    required this.includedFees,
    required this.poolInfo,
    this.lowLiquidityWarning,
    required this.estimatedDurationSeconds,
    required this.estimatedPrice,
    required this.type,
    this.dcaParams,
  });

  // Factory method to create a QuoteDetails object from JSON
  factory QuoteDetails.fromJson(Map<String, dynamic> json) {
    return QuoteDetails(
      intermediateAmount: json['intermediateAmount'],
      egressAmount: json['egressAmount'],
      includedFees: (json['includedFees'] as List<dynamic>)
          .map((fee) => ChainFlipSwapFee.fromJson(fee))
          .toList(),
      poolInfo: (json['poolInfo'] as List<dynamic>)
          .map((info) => PoolInfo.fromJson(info))
          .toList(),
      lowLiquidityWarning: json['lowLiquidityWarning'],
      estimatedDurationSeconds: json['estimatedDurationSeconds'],
      estimatedPrice: json['estimatedPrice'],
      type: QuoteType.fromName(json['type']), // Assuming QuoteType is an enum
      dcaParams: json['dcaParams'] != null
          ? DCAParams.fromJson(json['dcaParams'])
          : null,
    );
  }

  // Method to convert QuoteDetails object to JSON
  Map<String, dynamic> toJson() {
    return {
      'intermediateAmount': intermediateAmount,
      'egressAmount': egressAmount,
      'includedFees': includedFees.map((fee) => fee.toJson()).toList(),
      'poolInfo': poolInfo.map((info) => info.toJson()).toList(),
      'lowLiquidityWarning': lowLiquidityWarning,
      'estimatedDurationSeconds': estimatedDurationSeconds,
      'estimatedPrice': estimatedPrice,
      'type': type.name, // Assuming QuoteType is an enum
      'dcaParams': dcaParams?.toJson(),
    };
  }
}

class QuoteQueryResponse extends QuoteDetails {
  QuoteQueryResponse(
      {required String? intermediateAmount,
      required String egressAmount,
      required List<ChainFlipSwapFee> includedFees,
      required List<PoolInfo> poolInfo,
      required double estimatedDurationSeconds,
      required String estimatedPrice,
      bool? lowLiquidityWarning,
      DCAParams? dcaParams,
      this.boostQuote,
      required QuoteType type})
      : super(
            intermediateAmount: intermediateAmount,
            egressAmount: egressAmount,
            includedFees: includedFees,
            lowLiquidityWarning: lowLiquidityWarning,
            dcaParams: dcaParams,
            poolInfo: poolInfo,
            estimatedDurationSeconds: estimatedDurationSeconds,
            estimatedPrice: estimatedPrice,
            type: type);
  final int? boostQuote;

  factory QuoteQueryResponse.fromJson(Map<String, dynamic> json) {
    return QuoteQueryResponse(
      intermediateAmount: json['intermediateAmount'],
      egressAmount: json['egressAmount'],
      boostQuote: json["boostQuote"],
      includedFees: (json['includedFees'] as List<dynamic>)
          .map((fee) => ChainFlipSwapFee.fromJson(fee))
          .toList(),
      poolInfo: (json['poolInfo'] as List<dynamic>)
          .map((info) => PoolInfo.fromJson(info))
          .toList(),
      lowLiquidityWarning: json['lowLiquidityWarning'],
      estimatedDurationSeconds: json['estimatedDurationSeconds'],
      estimatedPrice: json['estimatedPrice'],
      type: QuoteType.fromName(json['type']),
      dcaParams: json['dcaParams'] != null
          ? DCAParams.fromJson(json['dcaParams'])
          : null,
    );
  }
}

class CCMMetadata {
  final String message;
  final String gasBudget;
  const CCMMetadata({required this.message, required this.gasBudget});
  Map<String, dynamic> toJson() {
    return {"message": message, "gas_budget": gasBudget};
  }
}

class FillOrKillParams {
  final String refundAddress;
  final int retryDurationBlocks;
  final String minPrice;
  const FillOrKillParams(
      {required this.refundAddress,
      required this.retryDurationBlocks,
      required this.minPrice});
  factory FillOrKillParams.fromJson(Map<String, dynamic> json) {
    return FillOrKillParams(
        refundAddress: json["refundAddress"],
        retryDurationBlocks: json["retryDurationBlocks"],
        minPrice: json["minPrice"]);
  }
  Map<String, dynamic> toJson() {
    return {
      "refund_address": refundAddress,
      "min_price": minPrice,
      "retry_duration_blocks": retryDurationBlocks
    };
  }
}

class DCAParams {
  final int numberOfChunks;
  final int chunkInterval;
  const DCAParams({required this.numberOfChunks, required this.chunkInterval});
  Map<String, dynamic> toJson() {
    return {
      "chunk_interval": chunkInterval,
      "number_of_chunks": numberOfChunks
    };
  }
}

class AffiliateFeesParams {
  final String account;
  final int bps;
  const AffiliateFeesParams({required this.account, required this.bps});
  Map<String, dynamic> toJson() {
    return {"account": account, "bps": bps};
  }
}

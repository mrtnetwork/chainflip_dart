import 'package:chain_flip/src/helper/extensions.dart';
import 'package:chain_flip/src/sdk/chain/types/asset_and_chain.dart';

class LimitOrderSide {
  final String name;
  const LimitOrderSide._(this.name);
  static const LimitOrderSide buy = LimitOrderSide._("buy");
  static const LimitOrderSide sell = LimitOrderSide._("sell");
  static List<LimitOrderSide> get values => [buy, sell];
}

class LimitOrder {
  final UncheckedAssetAndChain baseAsset;
  final UncheckedAssetAndChain quoteAsset;
  final LimitOrderSide side;
  final int tick;
  final BigInt sellAmount;
  const LimitOrder(
      {required this.baseAsset,
      required this.quoteAsset,
      required this.side,
      required this.tick,
      required this.sellAmount});
  Map<String, dynamic> toJson() {
    return {
      "base_asset": baseAsset.toJson(),
      "quote_asset": quoteAsset.toJson(),
      "side": side.name,
      "sell_amount": sellAmount.toHexDecimal
    };
  }
}

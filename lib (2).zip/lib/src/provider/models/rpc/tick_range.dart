class TickRange {
  final int start;
  final int end;
  const TickRange({required this.start, required this.end});

  Map<String, dynamic> toJson() {
    return {"start": start, "end": end};
  }
}

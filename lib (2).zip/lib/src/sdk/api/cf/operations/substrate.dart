import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:chain_flip/src/exception/exception.dart';
import 'package:chain_flip/src/sdk/api/cf/utils/utils.dart';
import 'package:chain_flip/src/sdk/chain/chain.dart';
import 'package:chain_flip/src/sdk/chain/types/asset_and_chain.dart';
import 'package:polkadot_dart/polkadot_dart.dart';

class _SubstrateOperationConst {
  static const String swappingPallet = "Swapping";
  static const String liquidityProvider = "LiquidityProvider";
}

abstract class ChainFlipOperationSerialization {
  Map<String, dynamic> template(CfNetwork network);
}

abstract class ChainFlipSubstrateOperation
    implements ChainFlipOperationSerialization {
  const ChainFlipSubstrateOperation();

  String get pallet;
  List<int> serializeCall(
      {required LatestMetadataInterface metadata, required CfNetwork network}) {
    final lockupId = metadata.getCallLookupId(pallet);
    final encode = [
      metadata.getPalletIndex(pallet),
      ...metadata.encodeLookup(
          id: lockupId, value: template(network), fromTemplate: true)
    ];
    return encode;
  }
}

class RegisterBrokerOperation extends ChainFlipSubstrateOperation {
  @override
  Map<String, dynamic> template(CfNetwork network) {
    return {
      "type": "Enum",
      "key": "register_as_broker",
      "value": null,
    };
  }

  @override
  String get pallet => _SubstrateOperationConst.swappingPallet;
}

class DeregisterBrokerOperation extends ChainFlipSubstrateOperation {
  @override
  Map<String, dynamic> template(CfNetwork network) {
    return {
      "type": "Enum",
      "key": "deregister_as_broker",
      "value": null,
    };
  }

  @override
  String get pallet => _SubstrateOperationConst.swappingPallet;
}

class OpenSwappingChannelOperation<T extends AssetAndChainAddress>
    extends ChainFlipSubstrateOperation {
  final AssetAndChain source;
  final T destination;
  final int brokerCommission;
  final RefundParameters<T>? refundParameters;
  final DCAParameters? dcaParameters;
  final List<AffiliateFees> affiliateFees;
  final ChannelMetadata? channelMetadata;
  final int boostFee;
  const OpenSwappingChannelOperation(
      {required this.source,
      required this.destination,
      required this.brokerCommission,
      required this.boostFee,
      this.refundParameters,
      this.dcaParameters,
      this.affiliateFees = const [],
      this.channelMetadata});

  @override
  Map<String, dynamic> template(CfNetwork network) {
    return {
      "key": "request_swap_deposit_address_with_affiliates",
      "value": {
        "value": {
          "source_asset": {
            "key": source.getVariant(),
            "value": null,
          },
          "destination_asset": {
            "key": destination.chain.getVariant(),
            "value": null,
          },
          "destination_address": {
            "key": destination.chain.chain.getChainVariant(),
            "value": {"value": destination.decodeToVariantBytes(network)},
          },
          "broker_commission": {"value": brokerCommission},
          "channel_metadata": {"value": channelMetadata?.template(network)},
          "boost_fee": {"value": boostFee},
          "affiliate_fees": {
            "value": affiliateFees
                .map((e) => {"value": e.template(network)})
                .toList()
          },
          "refund_parameters": {"value": refundParameters?.template(network)},
          "dca_parameters": {"value": dcaParameters?.template(network)}
        }
      }
    };
  }

  @override
  String get pallet => _SubstrateOperationConst.swappingPallet;
}

class ChannelMetadata implements ChainFlipOperationSerialization {
  final List<int> message;
  final BigInt gasBudget;
  final List<int> cfParameters;
  ChannelMetadata(
      {required List<int> message,
      required this.gasBudget,
      required List<int> cfParameters})
      : message = message.asImmutableBytes,
        cfParameters = cfParameters.asImmutableBytes;

  @override
  Map<String, dynamic> template(CfNetwork network) {
    return {
      "message": {"value": message},
      "gas_budget": {"value": gasBudget},
      "cf_parameters": {"value": cfParameters}
    };
  }
}

class AffiliateFees implements ChainFlipOperationSerialization {
  final SubstrateAddress address;
  final int bps;
  const AffiliateFees({required this.address, required this.bps});

  @override
  Map<String, dynamic> template(CfNetwork network) {
    return {
      "account": {"value": address.toBytes()},
      "bps": {"value": bps}
    };
  }
}

class RefundParameters<T extends AssetAndChainAddress>
    implements ChainFlipOperationSerialization {
  final List<BigInt> minPrice;
  final T refundAddress;
  final int retryDuration;
  RefundParameters({
    List<BigInt> minPrice = const [],
    required this.refundAddress,
    required int retryDuration,
  })  : minPrice = minPrice.map((e) => e.asUint64).toList(),
        retryDuration = retryDuration.asUint32;

  Map<String, dynamic> _addressTemplate(CfNetwork network) {
    switch (refundAddress.chain.chain) {
      case CfChain.solana:
      case CfChain.arbitrum:
      case CfChain.ethereum:
      case CfChain.polkadot:
        return {"value": refundAddress.decodeToVariantBytes(network)};
      case CfChain.bitcoin:
        return {
          "value": {
            "Btc": {
              "type": "Enum",
              "key": CfApiUtils.getBitcoinAddressVariant(refundAddress),
              "value": {
                "value": CfApiUtils.decodeBitcoinProgramAddress(refundAddress)
              },
            }
          }
        };
      default:
        throw DartChainFlipException("Invalid refund addresss");
    }
  }

  @override
  Map<String, dynamic> template(CfNetwork network) {
    return {
      "retry_duration": {"type": "U32", "value": retryDuration},
      "refund_address": {
        "type": "Enum",
        "key": refundAddress.chain.chain.getChainVariant(),
        "value": _addressTemplate(network),
      },
      "min_price": {"value": minPrice}
    };
  }
}

class DCAParameters implements ChainFlipOperationSerialization {
  final int numberOfChunks;
  final int chunkInterval;
  DCAParameters({required int numberOfChunks, required int chunkInterval})
      : numberOfChunks = numberOfChunks.asUint32,
        chunkInterval = chunkInterval.asUint32;

  @override
  Map<String, dynamic> template(CfNetwork network) {
    return {
      "number_of_chunks": {"value": numberOfChunks},
      "chunk_interval": {"value": chunkInterval}
    };
  }
}

class BrokerWithdrawOperation<T extends AssetAndChainAddress>
    extends ChainFlipSubstrateOperation {
  final T address;
  const BrokerWithdrawOperation(this.address);

  @override
  Map<String, dynamic> template(CfNetwork network) {
    return {
      "key": "withdraw",
      "value": {
        "value": {
          "asset": {
            "key": address.chain.getVariant(),
            "value": null,
          },
          "destination_address": {
            "key": address.chain.chain.getChainVariant(),
            "value": {"value": address.decodeToVariantBytes(network)},
          }
        }
      }
    };
  }

  @override
  String get pallet => _SubstrateOperationConst.swappingPallet;
}

class RegisterLiquidityAccountOperation extends ChainFlipSubstrateOperation {
  @override
  Map<String, dynamic> template(CfNetwork network) {
    return {
      "type": "Enum",
      "key": "register_lp_account",
      "value": null,
    };
  }

  @override
  String get pallet => _SubstrateOperationConst.liquidityProvider;
}

class DeregisterLiquidityAccountOperation extends ChainFlipSubstrateOperation {
  @override
  Map<String, dynamic> template(CfNetwork network) {
    return {
      "type": "Enum",
      "key": "deregister_lp_account",
      "value": null,
    };
  }

  @override
  String get pallet => _SubstrateOperationConst.liquidityProvider;
}

class LiquidityDepositAddressOperation extends ChainFlipSubstrateOperation {
  final AssetAndChain asset;
  final int boostFee;

  const LiquidityDepositAddressOperation(
      {required this.asset, required this.boostFee});

  @override
  Map<String, dynamic> template(CfNetwork network) {
    return {
      "key": "request_liquidity_deposit_address",
      "value": {
        "value": {
          "asset": {"type": "Enum", "key": asset.getVariant(), "value": null},
          "boost_fee": {"value": boostFee}
        }
      }
    };
  }

  @override
  String get pallet => _SubstrateOperationConst.liquidityProvider;
}

class RegisterLiquidityRefundAddressOperation<NETWORKADDRESS>
    extends ChainFlipSubstrateOperation {
  final CfChain chain;
  final NETWORKADDRESS refundAddress;

  const RegisterLiquidityRefundAddressOperation(
      {required this.chain, required this.refundAddress});

  @override
  Map<String, dynamic> template(CfNetwork network) {
    return {
      "key": "register_liquidity_refund_address",
      "value": {
        "type": "Map",
        "value": {
          "key": chain.getChainVariant(),
          "value": {
            "value": CfApiUtils.decodeAddress(
                chain: chain, address: refundAddress, network: network)
          }
        }
      }
    };
  }

  @override
  String get pallet => _SubstrateOperationConst.liquidityProvider;
}

class LiquidityWithdrawAssetOperation<T extends AssetAndChainAddress>
    extends ChainFlipSubstrateOperation {
  final T address;
  final BigInt amount;
  const LiquidityWithdrawAssetOperation(
      {required this.address, required this.amount});

  @override
  Map<String, dynamic> template(CfNetwork network) {
    return {
      "key": "withdraw_asset",
      "value": {
        "value": {
          "amount": {"value": amount},
          "asset": {"key": address.chain.getVariant()},
          "destination_address": {
            "key": address.chain.chain.getChainVariant(),
            "value": {"value": address.decodeToVariantBytes(network)},
          }
        }
      }
    };
  }

  @override
  String get pallet => _SubstrateOperationConst.liquidityProvider;
}

class LiquidityTransferAssetOperation extends ChainFlipSubstrateOperation {
  final AssetAndChain asset;
  final SubstrateAddress address;
  final BigInt amount;
  const LiquidityTransferAssetOperation(
      {required this.asset, required this.address, required this.amount});

  @override
  Map<String, dynamic> template(CfNetwork network) {
    return {
      "key": "transfer_asset",
      "value": {
        "value": {
          "amount": {"value": amount},
          "asset": {"key": asset.getVariant(), "value": null},
          "destination": {"value": address.toBytes()}
        }
      }
    };
  }

  @override
  String get pallet => _SubstrateOperationConst.liquidityProvider;
}

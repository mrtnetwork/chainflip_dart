import 'package:blockchain_utils/helper/helper.dart';
import 'package:chain_flip/src/sdk/chain/types/asset_and_chain.dart';
import 'package:chain_flip/src/sdk/api/cf/constant/const.dart';
import 'package:chain_flip/src/sdk/api/cf/models/models.dart';
import 'package:chain_flip/src/sdk/api/cf/operations/substrate.dart';
import 'package:on_chain/on_chain.dart';
import 'package:on_chain/solidity/address/core.dart';
import 'package:polkadot_dart/polkadot_dart.dart';

enum EvmOperationType { call, send }

abstract class EvmOperation {
  final AbiFunctionFragment fragment;
  final EvmOperationType type;
  const EvmOperation({required this.fragment, required this.type});
  List<dynamic> input();
}

abstract class EvmCallOperation<RESULT> extends EvmOperation {
  const EvmCallOperation({required AbiFunctionFragment fragment})
      : super(fragment: fragment, type: EvmOperationType.call);
  RESULT onResponse(List<dynamic> result) {
    return result[0] as RESULT;
  }
}

abstract class EvmExcuteOperation extends EvmOperation {
  const EvmExcuteOperation({required AbiFunctionFragment fragment})
      : super(fragment: fragment, type: EvmOperationType.send);
  List<int> encodeParams() {
    return fragment.encode(input());
  }
}

abstract class EvmFlipContractOperation<RESULT>
    extends EvmCallOperation<RESULT> {
  EvmFlipContractOperation({required AbiFunctionFragment fragment})
      : super(fragment: fragment);
}

abstract class EvmFlipContractExcuteOperation<RESULT>
    extends EvmExcuteOperation {
  EvmFlipContractExcuteOperation({required AbiFunctionFragment fragment})
      : super(fragment: fragment);
}

class EvmGetTokenBalanceOperation extends EvmFlipContractOperation<BigInt> {
  final ETHAddress address;
  EvmGetTokenBalanceOperation._(
      {required this.address, required AbiFunctionFragment fragment})
      : super(fragment: fragment);
  factory EvmGetTokenBalanceOperation(ETHAddress address) {
    return EvmGetTokenBalanceOperation._(
        address: address, fragment: CfApiConst.erc20BalaceFragment);
  }

  @override
  List input() {
    return [address];
  }
}

class EvmGetAllowanceOperation extends EvmFlipContractOperation<BigInt> {
  final ETHAddress address;
  EvmGetAllowanceOperation._(
      {required this.address, required AbiFunctionFragment fragment})
      : super(fragment: fragment);
  factory EvmGetAllowanceOperation(
      {required ETHAddress contractAddress, required ETHAddress address}) {
    return EvmGetAllowanceOperation._(
        address: address, fragment: CfApiConst.getAllowance);
  }

  @override
  List input() {
    return [address];
  }
}

class EvmTransferTokenOperation extends EvmFlipContractExcuteOperation {
  final ETHAddress destination;
  final BigInt amount;
  EvmTransferTokenOperation._(
      {required this.destination,
      required this.amount,
      required AbiFunctionFragment fragment})
      : super(fragment: fragment);
  factory EvmTransferTokenOperation(
      {required BigInt amount, required ETHAddress address}) {
    return EvmTransferTokenOperation._(
      destination: address,
      amount: amount,
      fragment: CfApiConst.transferFragment,
    );
  }

  @override
  List input() {
    return [destination, amount];
  }
}

class EvmIncreaseAllowanceOperation extends EvmFlipContractExcuteOperation {
  final ETHAddress address;
  final BigInt addedAmount;
  EvmIncreaseAllowanceOperation._(
      {required this.address,
      required this.addedAmount,
      required AbiFunctionFragment fragment})
      : super(fragment: fragment);
  factory EvmIncreaseAllowanceOperation(
      {required BigInt addedAmount, required ETHAddress address}) {
    return EvmIncreaseAllowanceOperation._(
      address: address,
      addedAmount: addedAmount,
      fragment: CfApiConst.increaseAllowance,
    );
  }

  @override
  List input() {
    return [address, addedAmount];
  }
}

class EvmDecreaseAllowanceOperation extends EvmFlipContractExcuteOperation {
  final ETHAddress address;
  final BigInt subtractedValue;
  EvmDecreaseAllowanceOperation._(
      {required this.address,
      required this.subtractedValue,
      required AbiFunctionFragment fragment})
      : super(fragment: fragment);
  factory EvmDecreaseAllowanceOperation(
      {required BigInt subtractedValue, required ETHAddress address}) {
    return EvmDecreaseAllowanceOperation._(
      address: address,
      subtractedValue: subtractedValue,
      fragment: CfApiConst.decreaseAllowance,
    );
  }

  @override
  List input() {
    return [address, subtractedValue];
  }
}

abstract class EvmStateChainGatewayExcuteOperation extends EvmExcuteOperation {
  EvmStateChainGatewayExcuteOperation({required AbiFunctionFragment fragment})
      : super(fragment: fragment);
}

abstract class EvmStateChainGatewayCallOperation<RESULT>
    extends EvmCallOperation<RESULT> {
  EvmStateChainGatewayCallOperation({required AbiFunctionFragment fragment})
      : super(fragment: fragment);
}

class EvmStateChainGatewayFundStateChainAccountOperation
    extends EvmStateChainGatewayExcuteOperation {
  final SubstrateAddress nodeId;
  final BigInt amount;
  EvmStateChainGatewayFundStateChainAccountOperation(
      {required this.nodeId, required this.amount})
      : super(fragment: CfApiConst.fundStateChainAccount);

  @override
  List input() {
    return [nodeId.toBytes(), amount];
  }
}

class EvmStateChainGatewayExecuteRedemptionOperation
    extends EvmStateChainGatewayExcuteOperation {
  final SubstrateAddress nodeId;

  EvmStateChainGatewayExecuteRedemptionOperation({required this.nodeId})
      : super(fragment: CfApiConst.executeRedemption);

  @override
  List input() {
    return [nodeId.toBytes()];
  }
}

class EvmStateChainGatewayGetMinimumFundingOperation
    extends EvmStateChainGatewayCallOperation<BigInt> {
  EvmStateChainGatewayGetMinimumFundingOperation()
      : super(fragment: CfApiConst.getMinimumFunding);

  @override
  List input() {
    return [];
  }
}

class EvmStateChainGatewayGetPendingRedemptionOperation
    extends EvmStateChainGatewayCallOperation<GetPendingRedemptionResult> {
  final SubstrateAddress nodeId;
  EvmStateChainGatewayGetPendingRedemptionOperation({required this.nodeId})
      : super(fragment: CfApiConst.getPendingRedemption);

  @override
  List input() {
    return [nodeId.toBytes()];
  }

  @override
  GetPendingRedemptionResult onResponse(List result) {
    final redemptionResult = result[0];
    final BigInt amount = redemptionResult[0];
    final SolidityAddress redeemAddress = redemptionResult[1];
    final BigInt startTime = redemptionResult[2];
    final BigInt expiryTime = redemptionResult[3];
    final SolidityAddress executor = redemptionResult[4];
    return GetPendingRedemptionResult(
        amount: amount,
        redeemAddress: redeemAddress,
        startTime: startTime.toInt(),
        executor: executor,
        expiryTime: expiryTime.toInt());
  }
}

class GetRedemptionDelayOperation
    extends EvmStateChainGatewayCallOperation<int> {
  GetRedemptionDelayOperation()
      : super(fragment: CfApiConst.getRedemptionDelay);

  @override
  List input() {
    return [];
  }

  @override
  int onResponse(List result) {
    return (result[0] as BigInt).toInt();
  }
}

abstract class EvmVaultExcuteOperation extends EvmExcuteOperation {
  EvmVaultExcuteOperation({required AbiFunctionFragment fragment})
      : super(fragment: fragment);
}

class EvmVaultXSwapTokenOperation extends EvmVaultExcuteOperation {
  final AssetAndChainAddress destination;
  final TokenContractAddress contractAddress;
  final BigInt amount;
  final List<int> cfParameters;
  EvmVaultXSwapTokenOperation(
      {required this.destination,
      required this.contractAddress,
      required this.amount,
      required List<int> cfParameters})
      : cfParameters = cfParameters.asImmutableBytes,
        super(fragment: CfApiConst.xSwapToken);

  @override
  List input() {
    return [
      destination.chain.chain.getChainVariantId(),
      destination.addressBytes(),
      destination.chain.chain.getAssetVariantId(destination.chain.asset),
      contractAddress.bytes,
      amount,
      cfParameters
    ];
  }
}

class EvmVaultXSwapNativeOperation extends EvmVaultExcuteOperation {
  final AssetAndChainAddress destination;
  final List<int> cfParameters;
  EvmVaultXSwapNativeOperation(
      {required this.destination, required List<int> cfParameters})
      : cfParameters = cfParameters.asImmutableBytes,
        super(fragment: CfApiConst.xSwapNative);

  @override
  List input() {
    return [
      destination.chain.chain.getChainVariantId(),
      destination.addressBytes(),
      destination.chain.chain.getAssetVariantId(destination.chain.asset),
      cfParameters
    ];
  }
}

class EvmVaultXCallNativeOperation extends EvmVaultExcuteOperation {
  final AssetAndChainAddress destination;
  final ChannelMetadata metadata;
  EvmVaultXCallNativeOperation({
    required this.destination,
    required this.metadata,
  }) : super(fragment: CfApiConst.xCallNative);

  @override
  List input() {
    return [
      destination.chain.chain.getChainVariantId(),
      destination.addressBytes(),
      destination.chain.chain.getAssetVariantId(destination.chain.asset),
      metadata.message,
      metadata.gasBudget,
      metadata.cfParameters
    ];
  }
}

class EvmVaultXCallTokenOperation extends EvmVaultExcuteOperation {
  final AssetAndChainAddress destination;
  final ChannelMetadata metadata;
  final BigInt amount;
  final TokenContractAddress srcToken;
  EvmVaultXCallTokenOperation(
      {required this.destination,
      required this.metadata,
      required this.amount,
      required this.srcToken})
      : super(fragment: CfApiConst.xCallToken);

  @override
  List input() {
    return [
      destination.chain.chain.getChainVariantId(),
      destination.addressBytes(),
      destination.chain.chain.getAssetVariantId(destination.chain.asset),
      metadata.message,
      metadata.gasBudget,
      srcToken.bytes,
      amount,
      metadata.cfParameters
    ];
  }
}


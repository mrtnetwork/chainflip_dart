import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:chain_flip/src/exception/exception.dart';
import 'package:chain_flip/src/sdk/chain/types/chain_flip_networks.dart';
import 'package:chain_flip/src/sdk/api/cf/core/core.dart';
import 'package:chain_flip/src/sdk/api/cf/models/models.dart';
import 'package:chain_flip/src/sdk/api/cf/operations/evm.dart';
import 'package:on_chain/on_chain.dart';

mixin CfEthereumApiImpl on CfEvmApiCore {
  CfNetwork get network;

  Future<ETHTransactionBuilder> buildEthereumTransaction(
      {required ETHAddress from,
      required ETHAddress to,
      required BigInt chainId,
      List<int>? data,
      required EVMRPC rpc,
      BigInt? nativeAmount,
      EVMTransactionParams? params}) async {
    final transaction = ETHTransactionBuilder(
      from: from,
      to: to,
      value: nativeAmount ?? BigInt.zero,
      chainId: chainId,
      memo: data == null ? null : BytesUtils.toHexString(data),
      transactionType: params?.transactionType,
    );
    params?.filledTransaction(transaction);
    await transaction.autoFill(rpc, params?.feeRate ?? EIP1559FeeRate.normal);
    return transaction;
  }

  Future<ETHTransactionBuilder> signTransaction(
      {required ETHTransactionBuilder transaction,
      required ETHPrivateKey signer}) async {
    transaction.sign(signer);
    return transaction;
  }

  Future<String> sendTransaction(
      {required ETHTransactionBuilder transaction, required EVMRPC rpc}) async {
    return transaction.sendTransaction(rpc);
  }

  Future<TransactionReceipt> sendAndSubmitTransaction(
      {required ETHTransactionBuilder transaction, required EVMRPC rpc}) async {
    return transaction.sendAndSubmitTransaction(rpc);
  }

  Future<T> callContract<T>(
      {required AbiFunctionFragment function,
      required List<dynamic> input,
      required EVMRPC rpc,
      required ETHAddress contractAddress,
      ETHAddress? from}) async {
    final call = await rpc.request(RPCCall.fromMethod(
        contractAddress: contractAddress.address,
        function: function,
        params: input,
        from: from?.address));
    return call;
  }

  Future<RESULT> callFlipContract<RESULT>(
      {required EvmFlipContractOperation<RESULT> operation,
      required EVMRPC rpc,
      ETHAddress? flipContractAddress,
      ETHAddress? from}) async {
    final call = await callContract(
        function: operation.fragment,
        input: operation.input(),
        rpc: rpc,
        contractAddress:
            flipContractAddress ?? ETHAddress(network.flipContractAddress),
        from: from);
    return operation.onResponse(call);
  }

  Future<RESULT> callStateChainGatewayContract<RESULT>(
      {required EvmStateChainGatewayCallOperation<RESULT> operation,
      required EVMRPC rpc,
      ETHAddress? stateChainGatewayAddress,
      ETHAddress? from}) async {
    final call = await callContract(
        function: operation.fragment,
        input: operation.input(),
        rpc: rpc,
        contractAddress: stateChainGatewayAddress ??
            ETHAddress(network.stateChainGatewayAddress),
        from: from);
    return operation.onResponse(call);
  }

  Future<ETHTransactionBuilder> buildContractTransaction({
    required AbiFunctionFragment function,
    required List<dynamic> functionInputs,
    required EVMRPC rpc,
    required ETHAddress account,
    required ETHAddress contractAddress,
    EVMTransactionParams? params,
    BigInt? chainId,
    BigInt? nativeAmount,
  }) async {
    if (function.payable ?? false) {
      if (nativeAmount == null) {
        throw DartChainFlipException(
            "Payable contract: This operation requires a certain amount of native currency to execute.");
      }
    }
    chainId ??= await rpc.request(RPCGetChainId());
    return buildEthereumTransaction(
        from: account,
        to: contractAddress,
        chainId: chainId ?? network.stateChainId,
        data: function.encode(functionInputs),
        rpc: rpc,
        nativeAmount: nativeAmount,
        params: params);
  }

  Future<ETHTransactionBuilder> buildStateChainGatewayContractTransaction({
    required EvmStateChainGatewayExcuteOperation operation,
    required EVMRPC rpc,
    required ETHAddress account,
    EVMTransactionParams? params,
    ETHAddress? stateChainGatewayAddress,
    BigInt? chainId,
    BigInt? nativeAmount,
  }) async {
    return buildContractTransaction(
        function: operation.fragment,
        functionInputs: operation.input(),
        contractAddress: stateChainGatewayAddress ??
            ETHAddress(network.stateChainGatewayAddress),
        chainId: chainId ?? network.stateChainId,
        account: account,
        rpc: rpc,
        nativeAmount: nativeAmount,
        params: params);
  }

  Future<ETHTransactionBuilder> buildVaultContractTransaction({
    required EvmVaultExcuteOperation operation,
    required EVMRPC rpc,
    required ETHAddress account,
    EVMTransactionParams? params,
    VaultContractChain? vaultChain,
    ETHAddress? vaultContractAddress,
    BigInt? chainId,
    BigInt? nativeAmount,
  }) async {
    if ((chainId != null && vaultContractAddress == null) ||
        (chainId == null && vaultContractAddress != null)) {
      throw DartChainFlipException(
          "Use the `chainId` and `vaultContractAddress` to detect the current contract's chain, or use `vaultChain` for detection.");
    }
    if (chainId == null || vaultContractAddress == null) {
      if (vaultChain == null) {
        throw DartChainFlipException(
            "Use the `chainId` and `vaultContractAddress` to detect the current contract's chain, or use `vaultChain` for detection.");
      }
      chainId = network.vaultChainId(vaultChain);
      vaultContractAddress =
          ETHAddress(network.getValueContractAddress(vaultChain));
    }
    return buildContractTransaction(
        function: operation.fragment,
        functionInputs: operation.input(),
        contractAddress: vaultContractAddress,
        chainId: chainId,
        account: account,
        rpc: rpc,
        nativeAmount: nativeAmount,
        params: params);
  }

  Future<ETHTransactionBuilder> buildFlipContractTransaction({
    required EvmFlipContractExcuteOperation operation,
    required EVMRPC rpc,
    required ETHAddress account,
    EVMTransactionParams? params,
    ETHAddress? flipContractAddress,
    BigInt? chainId,
    BigInt? nativeAmount,
  }) async {
    return buildContractTransaction(
        function: operation.fragment,
        functionInputs: operation.input(),
        contractAddress:
            flipContractAddress ?? ETHAddress(network.flipContractAddress),
        chainId: chainId ?? network.stateChainId,
        account: account,
        rpc: rpc,
        nativeAmount: nativeAmount,
        params: params);
  }
}

import 'package:blockchain_utils/bip/ecc/keys/ed25519_keys.dart';
import 'package:blockchain_utils/helper/helper.dart';
import 'package:chain_flip/src/exception/exception.dart';
import 'package:on_chain/on_chain.dart';

class SolanaTransactionParams {
  final SolAddress? recentBlockhash;
  final TransactionType type;
  final List<AddressLookupTableAccount>? addressLookupTableAccounts;
  final SolAddress payer;
  SolanaTransactionParams._({
    required this.recentBlockhash,
    required this.type,
    List<AddressLookupTableAccount>? addressLookupTableAccounts,
    required this.payer,
  }) : addressLookupTableAccounts = addressLookupTableAccounts?.immutable;
  factory SolanaTransactionParams.v0(
      {required SolAddress payer,
      SolAddress? recentBlockhash,
      List<AddressLookupTableAccount>? addressLookupTableAccounts}) {
    return SolanaTransactionParams._(
        recentBlockhash: recentBlockhash,
        type: TransactionType.v0,
        payer: payer,
        addressLookupTableAccounts: addressLookupTableAccounts);
  }
  factory SolanaTransactionParams.lagacy({
    required SolAddress payer,
    SolAddress? recentBlockhash,
  }) {
    return SolanaTransactionParams._(
        recentBlockhash: recentBlockhash,
        type: TransactionType.legacy,
        payer: payer);
  }
}

class SolanaIntractApi {
  Future<String> submitTransaction({
    required SolanaTransaction transaction,
    required SolanaRPC rpc,
    bool verifySignatures = true,
    Commitment? commitment = Commitment.finalized,
    bool skipPreflight = false,
    int? maxRetries,
    MinContextSlot? minContextSlot,
  }) async {
    final serializedTransaction =
        transaction.serializeString(verifySignatures: verifySignatures);
    return await rpc.request(SolanaRPCSendTransaction(
        encodedTransaction: serializedTransaction,
        commitment: commitment,
        maxRetries: maxRetries,
        skipPreflight: skipPreflight,
        minContextSlot: minContextSlot));
  }

  Future<SolanaTransaction> signTransaction(
      {required SolanaTransaction transaction,
      required List<SolanaPrivateKey> signers}) async {
    transaction.sign(signers);
    return transaction;
  }

  Future<SolanaTransaction> buildTransaction(
      {required List<TransactionInstruction> instructions,
      required SolanaTransactionParams params,
      required SolanaRPC rpc}) async {
    SolAddress? recentBlockhash = params.recentBlockhash;
    if (recentBlockhash == null) {
      final blockHash = await rpc.request(const SolanaRPCGetLatestBlockhash());
      recentBlockhash = blockHash.blockhash;
    }
    return SolanaTransaction(
        payerKey: params.payer,
        instructions: instructions,
        recentBlockhash: recentBlockhash);
  }

  Future<TransactionInstruction> buildTransferInstruction(
      {required BigInt lamports,
      required SolAddress source,
      required SolAddress destination,
      required SolanaRPC rpc,
      bool verifySourceIsUninitializedOrOwnedBySystemProgram = true}) async {
    if (verifySourceIsUninitializedOrOwnedBySystemProgram) {
      final destinationInfo =
          await rpc.request(SolanaRPCGetAccountInfo(account: destination));
      if (destinationInfo != null &&
          destinationInfo.owner != SystemProgramConst.programId) {
        throw DartChainFlipException(
            "Destination account is not owned by the System Program. Please verify the address or disable the `verifySourceIsUninitializedOrOwnedBySystemProgram` option.");
      }
    }
    return SystemProgram.transfer(
        layout: SystemTransferLayout(lamports: lamports),
        from: source,
        to: destination);
  }

  Future<TransactionInstruction> buildAssociatedTokenAccountInstruction(
      {required BigInt lamports,
      required SolAddress owner,
      required SolAddress mintAccount,
      required SolAddress payer,
      SolAddress tokenProgramId = SPLTokenProgramConst.tokenProgramId}) async {
    final associatedTokenAccount =
        AssociatedTokenAccountProgramUtils.associatedTokenAccount(
            mint: mintAccount, owner: owner, tokenProgramId: tokenProgramId);
    return AssociatedTokenAccountProgram.associatedTokenAccount(
        payer: payer,
        associatedToken: associatedTokenAccount.address,
        owner: owner,
        mint: mintAccount,
        tokenProgramId: tokenProgramId);
  }

  Future<TransactionInstruction> createAccountInstruction({
    BigInt? rentAmount,
    required int space,
    required SolAddress from,
    required SolAddress newAccountPubKey,
    required SolAddress payer,
    required SolanaRPC rpc,
    SolAddress programId = SPLTokenProgramConst.tokenProgramId,
  }) async {
    BigInt lamportsRent = rentAmount ?? BigInt.zero;
    if (rentAmount == null) {
      final rent = await rpc
          .request(SolanaRPCGetMinimumBalanceForRentExemption(size: space));
      lamportsRent = rent;
    }
    return SystemProgram.createAccount(
        from: from,
        newAccountPubKey: newAccountPubKey,
        layout: SystemCreateLayout(
            lamports: lamportsRent,
            space: BigInt.from(space),
            programId: SPLTokenProgramConst.tokenProgramId));
  }

  Future<List<TransactionInstruction>> transferToken({
    required SolAddress destination,
    required SolAddress mintAddress,
    required SolAddress owner,
    required BigInt tokenAmount,
    required SolanaRPC rpc,
    int? asTransferCheckDecimal,
    SolAddress tokenProgramId = SPLTokenProgramConst.tokenProgramId,
  }) async {
    if (!Ed25519PublicKey.isValidBytes(destination.toBytes())) {
      throw DartChainFlipException(
          "Invalid Solana public key provided. Please avoid using a PDA (Program Derived Address) as the destination address.");
    }
    if (!Ed25519PublicKey.isValidBytes(owner.toBytes())) {
      throw DartChainFlipException(
          "Invalid Solana public key provided. Please avoid using a PDA (Program Derived Address) as the source address.");
    }
    final destinationPda =
        AssociatedTokenAccountProgramUtils.associatedTokenAccount(
            mint: mintAddress,
            owner: destination,
            tokenProgramId: tokenProgramId);
    final ownerPda = AssociatedTokenAccountProgramUtils.associatedTokenAccount(
        mint: mintAddress, owner: owner, tokenProgramId: tokenProgramId);
    final destinationInfo = await rpc
        .request(SolanaRPCGetAccountInfo(account: destinationPda.address));
    TransactionInstruction? ascAccout;
    if (destinationInfo == null) {
      ascAccout = AssociatedTokenAccountProgram.associatedTokenAccount(
          payer: owner,
          associatedToken: destinationPda.address,
          owner: destination,
          mint: mintAddress,
          tokenProgramId: tokenProgramId);
    }
    TransactionInstruction transfer;
    if (asTransferCheckDecimal != null) {
      transfer = SPLTokenProgram.transferChecked(
          layout: SPLTokenTransferCheckedLayout(
              amount: tokenAmount, decimals: asTransferCheckDecimal),
          owner: owner,
          mint: mintAddress,
          source: ownerPda.address,
          programId: tokenProgramId,
          destination: destinationPda.address);
    } else {
      transfer = SPLTokenProgram.transfer(
          layout: SPLTokenTransferLayout(amount: tokenAmount),
          owner: owner,
          source: ownerPda.address,
          programId: tokenProgramId,
          destination: destinationPda.address);
    }
    return [if (ascAccout != null) ascAccout, transfer];
  }
}

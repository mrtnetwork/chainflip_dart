import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:chain_flip/src/exception/exception.dart';
import 'package:chain_flip/src/sdk/api/cf/models/models.dart';
import 'package:on_chain/on_chain.dart';
import 'package:polkadot_dart/polkadot_dart.dart';

class EthereumIntractApi {
  Future<ETHTransactionBuilder> buildEthereumTransaction(
      {required ETHAddress from,
      required ETHAddress to,
      required BigInt chainId,
      List<int>? data,
      required EVMRPC rpc,
      BigInt? nativeAmount,
      EVMTransactionParams? params}) async {
    final transaction = ETHTransactionBuilder(
      from: from,
      to: to,
      value: nativeAmount ?? BigInt.zero,
      chainId: chainId,
      memo: data == null ? null : BytesUtils.toHexString(data),
      transactionType: params?.transactionType,
    );
    params?.filledTransaction(transaction);
    await transaction.autoFill(rpc, params?.feeRate ?? EIP1559FeeRate.normal);
    return transaction;
  }

  Future<ETHTransactionBuilder> signTransaction(
      {required ETHTransactionBuilder transaction,
      required ETHPrivateKey signer}) async {
    transaction.sign(signer);
    return transaction;
  }

  Future<String> sendTransaction(
      {required ETHTransactionBuilder transaction, required EVMRPC rpc}) async {
    return transaction.sendTransaction(rpc);
  }

  Future<T> callContract<T>(
      {required AbiFunctionFragment function,
      required List<dynamic> input,
      required EVMRPC rpc,
      required ETHAddress contractAddress,
      ETHAddress? from}) async {
    final call = await rpc.request(RPCCall.fromMethod(
        contractAddress: contractAddress.address,
        function: function,
        params: input,
        from: from?.address));
    return call;
  }

  Future<ETHTransactionBuilder> buildContractTransaction({
    required AbiFunctionFragment function,
    required List<dynamic> functionInputs,
    required EVMRPC rpc,
    required ETHAddress account,
    required ETHAddress contractAddress,
    EVMTransactionParams? params,
    BigInt? chainId,
    BigInt? nativeAmount,
  }) async {
    if (function.payable ?? false) {
      if (nativeAmount == null) {
        throw DartChainFlipException(
            "Payable contract: This operation requires a certain amount of native currency to execute.");
      }
    }
    chainId ??= await rpc.request(RPCGetChainId());
    return buildEthereumTransaction(
        from: account,
        to: contractAddress,
        chainId: chainId!,
        data: function.encode(functionInputs),
        rpc: rpc,
        nativeAmount: nativeAmount,
        params: params);
  }


}

import 'package:bitcoin_base/bitcoin_base.dart';
import 'package:blockchain_utils/utils/binary/utils.dart';
import 'package:chain_flip/src/exception/exception.dart';

class SpenderInfo {
  final BitcoinAddress address;
  final String publicKey;
  const SpenderInfo._({required this.publicKey, required this.address});
  factory SpenderInfo(
      {required BitcoinAddress address, required String publicKey}) {
    return SpenderInfo._(
        publicKey: ECPublic.fromHex(publicKey).toHex(compressed: true),
        address: address);
  }
  String get pubkeyHash => address.baseAddress.pubKeyHash();
}

class BitcoinIntractApi {
  final BitcoinNetwork network;
  const BitcoinIntractApi(this.network);
  Future<List<UtxoWithAddress>> fetchUtxos(
      {required List<SpenderInfo> sources,
      required ElectrumApiProvider provider}) async {
    final List<UtxoWithAddress> accountsUtxos = [];
    for (final i in sources) {
      final elctrumUtxos = await provider
          .request(ElectrumScriptHashListUnspent(scriptHash: i.pubkeyHash));
      final List<UtxoWithAddress> utxos = elctrumUtxos
          .map((e) => UtxoWithAddress(
              utxo: e.toUtxo(i.address.type),
              ownerDetails: UtxoAddressDetails(
                  publicKey: i.publicKey, address: i.address.baseAddress)))
          .toList();
      accountsUtxos.addAll(utxos);
    }
    return accountsUtxos;
  }

  Future<BitcoinTransactionBuilder> buildTransaction(
      {required List<UtxoWithAddress> utxos,
      required List<BitcoinOutput> outputs,
      required BitcoinAddress changeAddress,
      required ElectrumApiProvider provider,
      BigInt? fee,
      BitcoinOrdering inputOrdering = BitcoinOrdering.bip69,
      BitcoinOrdering outputOrdering = BitcoinOrdering.bip69,
      bool enableRBF = false,
      List<int>? opReturn}) async {
    List<BitcoinOutput> outs = List<BitcoinOutput>.from(outputs);
    final sumOfUtxo = utxos.sumOfUtxosValue();
    if (sumOfUtxo <= BigInt.zero) {
      throw DartChainFlipException("No UTXOs found for spending");
    }
    if (fee != null && fee <= BigInt.zero) {
      throw DartChainFlipException(
          "Fee should not be zero or negative. You may also set the fee field to null to allow automatic fee calculation.");
    }
    BigInt sumOfOutputs = outs.fold<BigInt>(
        BigInt.zero, (previousValue, element) => previousValue + element.value);
    if (fee == null) {
      int transactionSize = BitcoinTransactionBuilder.estimateTransactionSize(
          utxos: utxos,
          outputs: [
            ...outs,
            BitcoinOutput(
                address: changeAddress.baseAddress, value: BigInt.zero)
          ],
          network: network,
          memo: BytesUtils.tryToHexString(opReturn),
          enableRBF: enableRBF);

      final networkEstimate = await provider.request(ElectrumEstimateFee());
      fee =
          BigInt.from(transactionSize) * (networkEstimate ~/ BigInt.from(1000));
    }
    final changeValue = sumOfUtxo - (sumOfOutputs + fee);
    if (changeValue.isNegative) {
      throw DartChainFlipException(
          "The sum of the provided outputs in satoshis plus the fee exceeds the UTXO balance.");
    } else if (changeValue > BigInt.zero) {
      outs.add(BitcoinOutput(
          address: changeAddress.baseAddress, value: changeValue));
    }
    return BitcoinTransactionBuilder(
        outPuts: outs,
        fee: fee,
        network: network,
        utxos: utxos,
        memo: BytesUtils.tryToHexString(opReturn),
        inputOrdering: inputOrdering,
        outputOrdering: outputOrdering,
        enableRBF: enableRBF);
  }

  Future<BtcTransaction> signTransaction(
      {required BitcoinTransactionBuilder transaction,
      required List<ECPrivate> signers}) async {
    return transaction.buildTransaction(
      (trDigest, utxo, publicKey, sighash) {
        final signer = signers.firstWhere(
            (e) => e.getPublic().toHex() == publicKey,
            orElse: () => throw DartChainFlipException(
                "Signer key not found for the provided public key in the UTXO."));
        if (utxo.utxo.isP2tr()) {
          return signer.signTapRoot(trDigest, sighash: sighash);
        }
        return signer.signInput(trDigest, sigHash: sighash);
      },
    );
  }

  Future<String> submitTransaction(
      {required BtcTransaction transaction,
      required ElectrumApiProvider provider}) async {
    return provider.request(
        ElectrumBroadCastTransaction(transactionRaw: transaction.serialize()));
  }
}

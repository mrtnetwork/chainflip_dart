import 'dart:async';
import 'package:chain_flip/src/exception/exception.dart';
import 'package:chain_flip/src/sdk/api/cf/api.dart';
import 'package:polkadot_dart/polkadot_dart.dart';

class SubstrateIntractApi {
  final MetadataApi api;
  const SubstrateIntractApi(this.api);
  List<int> buildCallBytes(
      {required String palletName,
      required Map<String, dynamic> inputs,
      bool inputGeneratedByTemplate = false}) {
    try {
      api.getCallLookupId(palletName);
    } catch (e) {
      throw DartChainFlipException(
          "The provided Substrate metadata does not support the pallet: $palletName.");
    }
    return api.encodeCall(
        palletNameOrIndex: palletName,
        value: inputs,
        fromTemplate: inputGeneratedByTemplate);
  }

  List<int> builTransferCallBytes(
      {required SubstrateAddress destination, required BigInt amount}) {
    final template = {
      "type": "Enum",
      "key": "transfer_allow_death",
      "value": {
        "value": {
          "dest": {
            "key": "Id",
            "value": {"value": destination.toBytes()},
          },
          "value": {"value": amount}
        }
      },
    };
    return buildCallBytes(
        inputs: template,
        palletName: "balances",
        inputGeneratedByTemplate: true);
  }

  Future<int> getAccountNonce(
      {required SubstrateRPC provider,
      required SubstrateAddress source}) async {
    final data = await api.getStorage(
        request: QueryStorageRequest<Map<String, dynamic>>(
            palletNameOrIndex: "System",
            methodName: "account",
            input: source.toBytes(),
            identifier: 0),
        rpc: provider,
        fromTemplate: false);
    return data.result["nonce"];
  }

  Future<BaseTransactionPayload> buildTransaction(
      {required SubstrateRPC provider,
      required List<int> callBytes,
      required SubstrateAddress source,
      String? genesisHash,
      String? blockHash,
      int? nonce}) async {
    final version = api.runtimeVersion();
    genesisHash ??= await provider
        .request(const SubstrateRPCChainGetBlockHash<String>(number: 0));
    nonce ??= await getAccountNonce(provider: provider, source: source);
    blockHash ??=
        await provider.request(const SubstrateRPCChainChainGetFinalizedHead());
    final blockHeader = await provider
        .request(SubstrateRPCChainChainGetHeader(atBlockHash: blockHash));
    final era = blockHeader.toMortalEra();
    if (api.metadata.isSupportMetadataHash) {
      return TransactionPayload(
          blockHash: SubstrateBlockHash.hash(blockHash!),
          era: era,
          genesisHash: SubstrateBlockHash.hash(genesisHash!),
          method: callBytes,
          nonce: nonce,
          specVersion: version.specVersion,
          transactionVersion: version.transactionVersion,
          tip: BigInt.zero);
    }
    return LegacyTransactionPayload(
        blockHash: SubstrateBlockHash.hash(blockHash!),
        era: era,
        genesisHash: SubstrateBlockHash.hash(genesisHash!),
        method: callBytes,
        nonce: nonce,
        specVersion: version.specVersion,
        transactionVersion: version.transactionVersion,
        tip: BigInt.zero);
  }

  Future<String> submitTransaction(
      {required SubstrateRPC provider, required Extrinsic extrinsic}) async {
    return await provider.request(
        SubstrateRPCAuthorSubmitExtrinsic(extrinsic.toHex(prefix: "0x")));
  }

  Stream<TransactionSubmitionResult> _findTransactionStream(
      {Duration retryInterval = const Duration(seconds: 4),
      required int blockId,
      required String extrinsic,
      required String transactionHash,
      required SubstrateRPC provider,
      int maxRetryEachBlock = 5,
      int blockCount = 20}) {
    final controller = StreamController<TransactionSubmitionResult>();
    void closeController() {
      if (!controller.isClosed) {
        controller.close();
      }
    }

    void startFetching() async {
      int id = blockId;
      int retry = maxRetryEachBlock;
      int count = blockCount;
      while (!controller.isClosed) {
        try {
          final result = await _lockupBlock(
              blockId: id,
              provider: provider,
              extrinsic: extrinsic,
              transactionHash: transactionHash);
          id++;
          count--;
          retry = maxRetryEachBlock;
          if (result != null) {
            controller.add(result);
            closeController();
          } else if (count <= 0) {
            controller.addError(DartChainFlipException(
                "Failed to fetch the block within the last ${blockCount} blocks."));
            closeController();
          }
        } on DartChainFlipException catch (e) {
          controller.addError(e);
          controller.close();
        } catch (_) {
          retry--;
          if (retry <= 0) {
            controller.addError(DartChainFlipException(
                "Failed to fetch the transaction within the allotted time."));
            closeController();
          }
        }
        await Future.delayed(retryInterval);
      }
    }

    startFetching();
    return controller.stream.asBroadcastStream(onCancel: (e) {
      controller.close();
      print("controller has been closed");
    });
  }

  Future<TransactionSubmitionResult> submitExtrinsicAndWatch(
      {required SubstrateRPC provider,
      required Extrinsic extrinsic,
      int maxRetryEachBlock = 5}) async {
    final blockHeader =
        await provider.request(SubstrateRPCChainChainGetHeader());
    final ext = extrinsic.toHex(prefix: "0x");
    final transactionHash =
        await provider.request(SubstrateRPCAuthorSubmitExtrinsic(ext));
    final completer = Completer<TransactionSubmitionResult>();
    StreamSubscription<TransactionSubmitionResult>? stream;
    try {
      stream = _findTransactionStream(
              blockId: blockHeader.number,
              provider: provider,
              extrinsic: ext,
              maxRetryEachBlock: maxRetryEachBlock,
              transactionHash: transactionHash)
          .listen(
              (e) async {
                completer.complete(e);
              },
              onDone: () {},
              onError: (e) {
                if (completer.isCompleted) return;
                if (e is DartChainFlipException) {
                  completer.completeError(DartChainFlipException(e.message,
                      details: {"tx": transactionHash, ...e.details ?? {}}));
                } else {
                  completer.completeError(DartChainFlipException(
                      "Failed to fetch the transaction. $transactionHash",
                      details: {"tx": transactionHash, "stack": e.toString()}));
                }
              });
      return await completer.future;
    } finally {
      stream?.cancel();
      stream = null;
    }
  }

  Future<TransactionSubmitionResult?> _lockupBlock(
      {required int blockId,
      required SubstrateRPC provider,
      required String extrinsic,
      required String transactionHash}) async {
    final blockHash = await provider
        .request(SubstrateRPCChainGetBlockHash<String?>(number: blockId));
    if (blockHash == null) {
      throw TypeError();
    }
    try {
      final block = await provider
          .request(SubstrateRPCChainGetBlock(atBlockHash: blockHash));
      final index = block.block.extrinsics.indexOf(extrinsic);
      if (index < 0) return null;
      final events =
          await api.getSystemEvents(provider, atBlockHash: blockHash);
      return TransactionSubmitionResult(
          events: events.where((e) => e.applyExtrinsic == index).toList(),
          block: blockHash,
          extrinsic: extrinsic,
          blockNumber: blockId,
          transactionHash: transactionHash);
    } catch (e) {
      throw DartChainFlipException("Somthing wrong when parsing block",
          details: {"block": blockHash, "stack": e.toString()});
    }
  }

  Extrinsic signTransaction(
      {required BaseTransactionPayload payload,
      required SubstratePrivateKey signer}) {
    final multiSignature = signer.multiSignature(payload.serialzeSign());
    final signature = payload.toExtrinsicSignature(
        signature: multiSignature, signer: signer.toAddress());
    return Extrinsic(signature: signature, methodBytes: payload.method);
  }
}
